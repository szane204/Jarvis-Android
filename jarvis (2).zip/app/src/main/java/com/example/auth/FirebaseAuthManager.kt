package com.example.auth

import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import com.example.BuildConfig
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

data class AuthUserState(
    val isAuthenticated: Boolean = false,
    val uid: String? = null,
    val displayName: String? = null,
    val email: String? = null,
    val photoUrl: String? = null
)

class FirebaseAuthManager(private val context: Context) {

    private val auth: FirebaseAuth? = try {
        FirebaseApp.initializeApp(context)
        FirebaseAuth.getInstance()
    } catch (e: Exception) {
        Log.w("FirebaseAuthManager", "Firebase initialization deferred: ${e.message}")
        null
    }

    private val credentialManager = CredentialManager.create(context)

    private val _currentUserState = MutableStateFlow(
        AuthUserState(
            isAuthenticated = auth?.currentUser != null,
            uid = auth?.currentUser?.uid,
            displayName = auth?.currentUser?.displayName,
            email = auth?.currentUser?.email,
            photoUrl = auth?.currentUser?.photoUrl?.toString()
        )
    )
    val currentUserState: StateFlow<AuthUserState> = _currentUserState.asStateFlow()

    init {
        auth?.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            _currentUserState.value = AuthUserState(
                isAuthenticated = user != null,
                uid = user?.uid,
                displayName = user?.displayName,
                email = user?.email,
                photoUrl = user?.photoUrl?.toString()
            )
        }
    }

    fun getCurrentUser(): FirebaseUser? {
        return auth?.currentUser
    }

    suspend fun signInWithGoogle(webClientId: String): Result<FirebaseUser?> {
        val fbAuth = auth ?: return Result.failure(IllegalStateException("Firebase is not initialized."))

        return try {
            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(webClientId.ifBlank { "dummy_client_id.apps.googleusercontent.com" })
                .setAutoSelectEnabled(false)
                .build()

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val result: GetCredentialResponse = credentialManager.getCredential(
                request = request,
                context = context
            )

            val credential = result.credential
            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val idToken = googleIdTokenCredential.idToken

                val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
                val authResult = fbAuth.signInWithCredential(firebaseCredential).await()
                val user = authResult.user

                _currentUserState.value = AuthUserState(
                    isAuthenticated = user != null,
                    uid = user?.uid,
                    displayName = user?.displayName,
                    email = user?.email,
                    photoUrl = user?.photoUrl?.toString()
                )
                Result.success(user)
            } else {
                Result.failure(IllegalArgumentException("Unexpected credential type returned."))
            }
        } catch (e: Exception) {
            Log.e("FirebaseAuthManager", "Google Sign-In failed", e)
            Result.failure(e)
        }
    }

    suspend fun signOut() {
        try {
            auth?.signOut()
            credentialManager.clearCredentialState(ClearCredentialStateRequest())
            _currentUserState.value = AuthUserState(isAuthenticated = false)
        } catch (e: Exception) {
            Log.e("FirebaseAuthManager", "Sign out error", e)
        }
    }
}
