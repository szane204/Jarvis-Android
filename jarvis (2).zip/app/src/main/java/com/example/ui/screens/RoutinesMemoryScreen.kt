package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MemoryItem
import com.example.data.model.RoutineItem
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavyCardBorder
import com.example.ui.theme.DeepVoidBlack
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.HologramAmber
import com.example.ui.theme.HologramGreen
import com.example.ui.theme.HologramRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextCyberDim
import com.example.ui.theme.TextCyberMuted
import com.example.ui.theme.TextCyberWhite

@Composable
fun RoutinesMemoryScreen(
    routines: List<RoutineItem>,
    memories: List<MemoryItem>,
    onTriggerRoutine: (RoutineItem) -> Unit,
    onSaveRoutine: (String, String, String, String) -> Unit,
    onDeleteRoutine: (Int) -> Unit,
    onSaveMemory: (String, String, String) -> Unit,
    onDeleteMemory: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var showAddRoutineDialog by remember { mutableStateOf(false) }
    var showAddMemoryDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepVoidBlack)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "MEMORY & ROUTINES",
                    color = NeonCyan,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Personalized autonomous workflows & memory banks",
                    color = TextCyberDim,
                    fontSize = 12.sp
                )
            }

            IconButton(
                onClick = {
                    if (selectedTab == 0) showAddRoutineDialog = true else showAddMemoryDialog = true
                },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(NeonCyan)
                    .testTag("add_item_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add New Item",
                    tint = DeepVoidBlack
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Tab Row
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkNavyCard,
            contentColor = NeonCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = NeonCyan
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("ROUTINES (${routines.size})", fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("MEMORY BANK (${memories.size})", fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (selectedTab == 0) {
            // Routines list
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 32.dp)
            ) {
                items(routines) { routine ->
                    RoutineCard(
                        routine = routine,
                        onExecute = { onTriggerRoutine(routine) },
                        onDelete = { onDeleteRoutine(routine.id) }
                    )
                }
            }
        } else {
            // Memories list
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 32.dp)
            ) {
                items(memories) { memory ->
                    MemoryCard(
                        memory = memory,
                        onDelete = { onDeleteMemory(memory.id) }
                    )
                }
            }
        }
    }

    // Add Routine Dialog
    if (showAddRoutineDialog) {
        var name by remember { mutableStateOf("") }
        var trigger by remember { mutableStateOf("") }
        var steps by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddRoutineDialog = false },
            title = { Text("New Routine", color = TextCyberWhite, fontFamily = FontFamily.Monospace) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Routine Name") },
                        colors = outlinedColors()
                    )
                    OutlinedTextField(
                        value = trigger,
                        onValueChange = { trigger = it },
                        label = { Text("Voice Trigger (e.g. 'Work mode')") },
                        colors = outlinedColors()
                    )
                    OutlinedTextField(
                        value = steps,
                        onValueChange = { steps = it },
                        label = { Text("Steps (one command per line)") },
                        colors = outlinedColors(),
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank() && trigger.isNotBlank()) {
                            onSaveRoutine(name, "User-defined routine", trigger, steps)
                            showAddRoutineDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = DeepVoidBlack)
                ) {
                    Text("Save Routine")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddRoutineDialog = false }) {
                    Text("Cancel")
                }
            },
            containerColor = DarkNavyCard
        )
    }

    // Add Memory Dialog
    if (showAddMemoryDialog) {
        var key by remember { mutableStateOf("") }
        var value by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("preferences") }

        AlertDialog(
            onDismissRequest = { showAddMemoryDialog = false },
            title = { Text("Store Fact / Preference", color = TextCyberWhite, fontFamily = FontFamily.Monospace) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = key,
                        onValueChange = { key = it },
                        label = { Text("Preference Key (e.g. 'preferred_email')") },
                        colors = outlinedColors()
                    )
                    OutlinedTextField(
                        value = value,
                        onValueChange = { value = it },
                        label = { Text("Value (e.g. 'Gmail' or 'David')") },
                        colors = outlinedColors()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (key.isNotBlank() && value.isNotBlank()) {
                            onSaveMemory(key, value, category)
                            showAddMemoryDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = DeepVoidBlack)
                ) {
                    Text("Commit to Memory")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddMemoryDialog = false }) {
                    Text("Cancel")
                }
            },
            containerColor = DarkNavyCard
        )
    }
}

@Composable
private fun RoutineCard(
    routine: RoutineItem,
    onExecute: () -> Unit,
    onDelete: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkNavyCard)
            .border(1.dp, DarkNavyCardBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = routine.name,
                    color = TextCyberWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Trigger: \"${routine.triggerPhrase}\"",
                    color = NeonCyan,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = routine.stepsRaw.replace("\n", " → "),
                    color = TextCyberDim,
                    fontSize = 11.sp,
                    maxLines = 2
                )
            }

            Row {
                IconButton(onClick = onExecute) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Run Routine",
                        tint = HologramGreen
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete Routine",
                        tint = HologramRed.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}

@Composable
private fun MemoryCard(
    memory: MemoryItem,
    onDelete: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkNavyCard)
            .border(1.dp, DarkNavyCardBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = memory.key.uppercase(),
                    color = NeonCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = memory.value,
                    color = TextCyberWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Category: ${memory.category}",
                    color = TextCyberDim,
                    fontSize = 10.sp
                )
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete Memory",
                    tint = HologramRed.copy(alpha = 0.7f)
                )
            }
        }
    }
}

@Composable
private fun outlinedColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = NeonCyan,
    unfocusedBorderColor = DarkNavyCardBorder,
    focusedTextColor = TextCyberWhite,
    unfocusedTextColor = TextCyberWhite,
    cursorColor = NeonCyan,
    focusedLabelColor = NeonCyan,
    unfocusedLabelColor = TextCyberDim
)
