package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.ActionPlan
import com.example.model.ChatMessage
import com.example.model.GeneratedMedia
import com.example.model.JarvisState
import com.example.model.MediaAttachment
import com.example.model.MediaType
import com.example.model.MessageSender
import com.example.model.VideoStoryboard
import com.example.ui.components.JarvisHologramAvatar
import com.example.ui.components.JarvisTelemetryHeader
import com.example.ui.components.TaskPlanCard
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavyCardBorder
import com.example.ui.theme.DeepVoidBlack
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.HologramAmber
import com.example.ui.theme.HologramGreen
import com.example.ui.theme.HologramRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextCyberDim
import com.example.ui.theme.TextCyberMuted
import com.example.ui.theme.TextCyberWhite
import com.example.util.ImageUtils
import com.example.voice.JarvisVoiceStatus
import kotlinx.coroutines.launch

@Composable
fun MainConsoleScreen(
    state: JarvisState,
    voiceStatus: JarvisVoiceStatus,
    rmsAmplitude: Float,
    messages: List<ChatMessage>,
    currentPlan: ActionPlan?,
    pendingConfirmationPlan: ActionPlan?,
    pendingAttachment: MediaAttachment?,
    isAccessibilityConnected: Boolean,
    isNotificationListenerConnected: Boolean,
    isWakeWordEnabled: Boolean,
    isAlwaysListening: Boolean,
    isListening: Boolean,
    isSpeaking: Boolean,
    partialSpeechText: String,
    speechError: String?,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
    onStopSpeaking: () -> Unit,
    onStopRequested: () -> Unit,
    onSetAttachment: (MediaAttachment?) -> Unit,
    onSubmitText: (String) -> Unit,
    onConfirmPlan: () -> Unit,
    onCancelPlan: () -> Unit,
    onNavigateToDiagnostics: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Zero-permission Android Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                val b64 = ImageUtils.uriToBase64(context, uri)
                onSetAttachment(
                    MediaAttachment(
                        uri = uri.toString(),
                        type = MediaType.IMAGE,
                        base64Data = b64,
                        mimeType = "image/jpeg",
                        title = "Selected Image"
                    )
                )
            }
        }
    }

    // Auto-scroll to newest message
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val quickPrompts = listOf(
        "Generate an image of a futuristic Iron Man helmet in 8k",
        "Make a cinematic video of a spaceship flying through a nebula",
        "Who is Elon Musk?",
        "What's the capital of Japan?",
        "Tell me something interesting",
        "Open WhatsApp",
        "Open Instagram",
        "Take a screenshot",
        "Read my notifications"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepVoidBlack)
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        // 1. Top Telemetry Header
        JarvisTelemetryHeader(
            state = state,
            isAccessibilityConnected = isAccessibilityConnected,
            isNotificationListenerConnected = isNotificationListenerConnected,
            isWakeWordActive = isWakeWordEnabled,
            onNavigateToDiagnostics = onNavigateToDiagnostics,
            onNavigateToSettings = onNavigateToSettings
        )

        Spacer(modifier = Modifier.height(6.dp))

        // 2. Central Stage: Futuristic Holographic AI Face Avatar + Real-Time Status & Interruption
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Interactive Holographic Face Avatar: Tap to listen or interrupt
                JarvisHologramAvatar(
                    state = state,
                    rmsAmplitude = rmsAmplitude,
                    isSpeaking = isSpeaking,
                    size = 185.dp,
                    onClick = {
                        if (isSpeaking || state == JarvisState.SPEAKING || state == JarvisState.THINKING || state == JarvisState.GENERATING) {
                            onStopRequested()
                        } else if (isListening) {
                            onStopVoice()
                        } else {
                            onStartVoice()
                        }
                    }
                )

                Spacer(modifier = Modifier.height(2.dp))

                val statusLabel = when {
                    isSpeaking || state == JarvisState.SPEAKING -> "SPEAKING // TAP TO INTERRUPT"
                    state == JarvisState.GENERATING || voiceStatus == JarvisVoiceStatus.GENERATING -> "GENERATING AI MEDIA..."
                    state == JarvisState.THINKING || voiceStatus == JarvisVoiceStatus.THINKING -> "THINKING & PROCESSING..."
                    state == JarvisState.EXECUTING -> "EXECUTING TASK..."
                    state == JarvisState.ERROR || voiceStatus == JarvisVoiceStatus.ERROR -> "SYSTEM ERROR // CHECK LOGS"
                    isListening || voiceStatus == JarvisVoiceStatus.LISTENING -> "LISTENING..."
                    voiceStatus == JarvisVoiceStatus.WAKING -> "ONLINE // AT YOUR SERVICE"
                    else -> if (isWakeWordEnabled) "STANDBY // SAY \"HEY JARVIS\"" else "STANDBY // TAP MIC"
                }

                val statusColor by animateColorAsState(
                    targetValue = when {
                        isSpeaking || state == JarvisState.SPEAKING -> ElectricBlue
                        state == JarvisState.GENERATING || voiceStatus == JarvisVoiceStatus.GENERATING -> HologramAmber
                        state == JarvisState.THINKING || voiceStatus == JarvisVoiceStatus.THINKING -> HologramAmber
                        state == JarvisState.EXECUTING -> NeonCyan
                        state == JarvisState.ERROR || voiceStatus == JarvisVoiceStatus.ERROR -> HologramRed
                        isListening || voiceStatus == JarvisVoiceStatus.LISTENING -> HologramGreen
                        voiceStatus == JarvisVoiceStatus.WAKING -> HologramGreen
                        else -> NeonCyan
                    },
                    label = "status_color"
                )

                Text(
                    text = statusLabel,
                    color = statusColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )

                // Prominent "JARVIS STOP" pill if active
                if (isSpeaking || state == JarvisState.SPEAKING || state == JarvisState.THINKING || state == JarvisState.GENERATING) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(HologramRed.copy(alpha = 0.2f))
                            .border(1.dp, HologramRed, RoundedCornerShape(12.dp))
                            .clickable { onStopRequested() }
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                            .testTag("jarvis_stop_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop",
                            tint = HologramRed,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "JARVIS STOP",
                            color = HologramRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Live Speech Subtitles
                if (isListening) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.92f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkNavyCard.copy(alpha = 0.85f))
                            .border(1.dp, HologramGreen.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (partialSpeechText.isNotBlank()) "\"$partialSpeechText\"" else "Listening for speech...",
                            color = HologramGreen,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                if (!speechError.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = speechError,
                        color = HologramAmber,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // 3. Quick Multimodal Prompt Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickPrompts.forEach { prompt ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(DarkNavyCard)
                        .border(1.dp, DarkNavyCardBorder, RoundedCornerShape(16.dp))
                        .clickable { onSubmitText(prompt) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = prompt,
                        color = TextCyberWhite,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 4. Conversation History Transcript (with Multimodal Image and Video Storyboard support)
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (pendingConfirmationPlan != null) {
                item {
                    TaskPlanCard(
                        plan = pendingConfirmationPlan,
                        isPendingConfirmation = true,
                        onConfirm = onConfirmPlan,
                        onCancel = onCancelPlan
                    )
                }
            } else if (currentPlan != null && currentPlan.steps.isNotEmpty()) {
                item {
                    TaskPlanCard(
                        plan = currentPlan,
                        isPendingConfirmation = false,
                        onConfirm = onConfirmPlan,
                        onCancel = onCancelPlan
                    )
                }
            }

            items(messages) { msg ->
                MultimodalChatBubble(message = msg)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 5. Active Pending Attachment Preview
        if (pendingAttachment != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(DarkNavyCard)
                    .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = "Attached Image",
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = pendingAttachment.title ?: "Image Attached (Ready for Vision / Edit)",
                        color = TextCyberWhite,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                IconButton(
                    onClick = { onSetAttachment(null) },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Remove attachment",
                        tint = HologramRed,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        // 6. Input Control Dock (Mic button, Attach Image, Mode indicator & Text Input)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(DarkNavyCard)
                .border(1.dp, DarkNavyCardBorder, RoundedCornerShape(24.dp))
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Voice Mic Button
            FloatingActionButton(
                onClick = {
                    if (isSpeaking) {
                        onStopRequested()
                    } else if (isListening) {
                        onStopVoice()
                    } else {
                        onStartVoice()
                    }
                },
                modifier = Modifier
                    .size(46.dp)
                    .testTag("voice_command_button"),
                shape = CircleShape,
                containerColor = if (isListening) HologramGreen else NeonCyan,
                contentColor = DeepVoidBlack
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = if (isListening) "Stop Listening" else "Speak to JARVIS",
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Attachment Picker Button (Photo Picker)
            IconButton(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier
                    .size(36.dp)
                    .testTag("attach_media_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AddPhotoAlternate,
                    contentDescription = "Attach Photo or Screenshot",
                    tint = NeonCyan,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Text Input Field
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = {
                    Text(
                        text = if (isListening) "Listening..." else if (pendingAttachment != null) "Ask JARVIS about image..." else "Message JARVIS...",
                        color = TextCyberMuted,
                        fontSize = 12.sp
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (textInput.isNotBlank() || pendingAttachment != null) {
                            onSubmitText(textInput)
                            textInput = ""
                        }
                    }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedTextColor = TextCyberWhite,
                    unfocusedTextColor = TextCyberWhite,
                    cursorColor = NeonCyan
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("command_input_field")
            )

            // Submit Button
            IconButton(
                onClick = {
                    if (textInput.isNotBlank() || pendingAttachment != null) {
                        onSubmitText(textInput)
                        textInput = ""
                    }
                },
                modifier = Modifier.testTag("send_command_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send Message",
                    tint = if (textInput.isNotBlank() || pendingAttachment != null) NeonCyan else TextCyberMuted
                )
            }
        }
    }
}

@Composable
private fun MultimodalChatBubble(message: ChatMessage) {
    val isUser = message.sender == MessageSender.USER
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(
                    RoundedCornerShape(
                        topStart = 14.dp,
                        topEnd = 14.dp,
                        bottomStart = if (isUser) 14.dp else 2.dp,
                        bottomEnd = if (isUser) 2.dp else 14.dp
                    )
                )
                .background(if (isUser) ElectricBlue.copy(alpha = 0.22f) else DarkNavyCard.copy(alpha = 0.95f))
                .border(
                    1.dp,
                    if (isUser) ElectricBlue.copy(alpha = 0.5f) else DarkNavyCardBorder,
                    RoundedCornerShape(
                        topStart = 14.dp,
                        topEnd = 14.dp,
                        bottomStart = if (isUser) 14.dp else 2.dp,
                        bottomEnd = if (isUser) 2.dp else 14.dp
                    )
                )
                .padding(12.dp)
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isUser) "USER" else "JARVIS",
                        color = if (isUser) ElectricBlue else NeonCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 0.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // User attachment preview if present
                if (message.attachment?.uri != null) {
                    AsyncImage(
                        model = message.attachment.uri,
                        contentDescription = "Attached Image",
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 200.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, DarkNavyCardBorder, RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // AI Generated Audio / Music (Lyria 3)
                if (message.generatedMedia != null && message.generatedMedia.type == MediaType.AUDIO) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(DeepVoidBlack)
                            .border(1.dp, HologramAmber.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = HologramAmber,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "LYRIA 3 SYNTHESIZED SOUNDTRACK",
                                    color = HologramAmber,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = "AUDIO // 30S",
                                color = TextCyberDim,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "\"${message.generatedMedia.prompt}\"",
                            color = TextCyberWhite,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(DarkNavyCard)
                                .padding(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play Audio",
                                tint = NeonCyan,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Lyria 3 audio ready to play",
                                color = TextCyberDim,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // AI Generated Image rendering
                if (message.generatedMedia != null && message.generatedMedia.type == MediaType.IMAGE) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(DeepVoidBlack)
                            .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Image,
                                    contentDescription = null,
                                    tint = NeonCyan,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "AI GENERATED ARTWORK",
                                    color = NeonCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = message.generatedMedia.resolution ?: "1024x1024",
                                color = TextCyberDim,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        AsyncImage(
                            model = message.generatedMedia.urlOrPath,
                            contentDescription = message.generatedMedia.prompt,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clip(RoundedCornerShape(6.dp)),
                            contentScale = ContentScale.Crop
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "\"${message.generatedMedia.prompt}\"",
                            color = TextCyberDim,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // Cinematic Video Storyboard rendering
                if (message.videoStoryboard != null) {
                    val sb = message.videoStoryboard
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(DeepVoidBlack)
                            .border(1.dp, HologramAmber.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Movie,
                                    contentDescription = null,
                                    tint = HologramAmber,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = sb.title.uppercase(),
                                    color = HologramAmber,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = "${sb.durationSeconds}S // ${sb.aspectRatio}",
                                color = TextCyberDim,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "MASTER VIDEO PROMPT:",
                            color = NeonCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = sb.masterPrompt,
                            color = TextCyberWhite,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "CAMERA: ${sb.cameraMovement}",
                            color = TextCyberDim,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "LIGHTING: ${sb.lightingAtmosphere}",
                            color = TextCyberDim,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        sb.scenes.forEach { scene ->
                            Text(
                                text = "• $scene",
                                color = TextCyberWhite,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(vertical = 1.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(DarkNavyCard)
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "VIDEO API: Veo / Runway Gen-3 Ready",
                                color = HologramAmber,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // Spoken or generated text response
                Text(
                    text = message.text,
                    color = TextCyberWhite,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}
