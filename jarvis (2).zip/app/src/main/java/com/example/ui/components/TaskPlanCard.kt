package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActionPlan
import com.example.model.PlanStep
import com.example.model.RiskLevel
import com.example.model.StepStatus
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavyCardBorder
import com.example.ui.theme.DeepVoidBlack
import com.example.ui.theme.HologramAmber
import com.example.ui.theme.HologramGreen
import com.example.ui.theme.HologramRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextCyberDim
import com.example.ui.theme.TextCyberWhite

@Composable
fun TaskPlanCard(
    plan: ActionPlan,
    isPendingConfirmation: Boolean,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(DarkNavyCard.copy(alpha = 0.85f))
            .border(1.dp, if (isPendingConfirmation) HologramAmber else DarkNavyCardBorder, RoundedCornerShape(16.dp))
            .padding(16.dp)
            .testTag("task_plan_card")
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isPendingConfirmation) HologramAmber else NeonCyan)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isPendingConfirmation) "AUTHORIZATION REQUIRED" else "TASK EXECUTION PLAN",
                        color = if (isPendingConfirmation) HologramAmber else NeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Risk Badge
                val (riskColor, riskText) = when (plan.riskLevel) {
                    RiskLevel.HIGH -> HologramRed to "HIGH RISK"
                    RiskLevel.MEDIUM -> HologramAmber to "MODERATE"
                    RiskLevel.LOW -> HologramGreen to "STANDARD"
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(riskColor.copy(alpha = 0.15f))
                        .border(1.dp, riskColor.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = riskText,
                        color = riskColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = plan.userIntent,
                color = TextCyberWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )

            // Confirmation details if applicable
            if (isPendingConfirmation && plan.confirmationDetails.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DeepVoidBlack.copy(alpha = 0.6f))
                        .padding(10.dp)
                ) {
                    plan.confirmationDetails.forEach { (k, v) ->
                        Row(modifier = Modifier.padding(vertical = 2.dp)) {
                            Text(
                                text = "$k: ",
                                color = TextCyberDim,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = v,
                                color = TextCyberWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Steps breakdown
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                plan.steps.forEach { step ->
                    StepRow(step = step)
                }
            }

            // Action Confirmation Buttons
            AnimatedVisibility(
                visible = isPendingConfirmation,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Column {
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onCancel,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("cancel_plan_button"),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, HologramRed.copy(alpha = 0.6f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = HologramRed)
                        ) {
                            Text("Abort", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }

                        Button(
                            onClick = onConfirm,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("confirm_plan_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = HologramGreen,
                                contentColor = DeepVoidBlack
                            )
                        ) {
                            Text("Confirm & Execute", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StepRow(step: PlanStep) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        // Status indicator
        when (step.status) {
            StepStatus.PENDING -> {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .border(1.5.dp, TextCyberDim.copy(alpha = 0.5f), CircleShape)
                )
            }
            StepStatus.RUNNING -> {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = NeonCyan
                )
            }
            StepStatus.SUCCESS -> {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(HologramGreen),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Success",
                        tint = DeepVoidBlack,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
            StepStatus.FAILED -> {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(HologramRed),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Failed",
                        tint = TextCyberWhite,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
            StepStatus.CANCELLED -> {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(TextCyberDim),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Cancelled",
                        tint = DeepVoidBlack,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = step.title,
                color = when (step.status) {
                    StepStatus.SUCCESS -> HologramGreen
                    StepStatus.FAILED -> HologramRed
                    StepStatus.RUNNING -> NeonCyan
                    else -> TextCyberDim
                },
                fontSize = 12.sp,
                fontWeight = if (step.status == StepStatus.RUNNING) FontWeight.Bold else FontWeight.Normal,
                fontFamily = FontFamily.Monospace
            )
            if (!step.resultDetail.isNullOrBlank()) {
                Text(
                    text = step.resultDetail ?: "",
                    color = TextCyberDim,
                    fontSize = 11.sp,
                    maxLines = 2
                )
            }
        }
    }
}
