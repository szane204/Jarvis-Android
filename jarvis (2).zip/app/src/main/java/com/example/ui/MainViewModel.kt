package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.JarvisApp
import com.example.accessibility.JarvisAccessibilityService
import com.example.data.model.MemoryItem
import com.example.data.model.RoutineItem
import com.example.model.ActionPlan
import com.example.model.ChatMessage
import com.example.model.JarvisState
import com.example.model.MediaAttachment
import com.example.notifications.JarvisNotificationListenerService
import com.example.voice.JarvisVoiceService
import com.example.voice.JarvisVoiceStatus
import com.example.voice.VoiceManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as JarvisApp
    val repository = app.repository
    val brain = app.brain

    val state: StateFlow<JarvisState> = brain.state
    val messages: StateFlow<List<ChatMessage>> = brain.messages
    val currentPlan: StateFlow<ActionPlan?> = brain.currentPlan
    val pendingConfirmationPlan: StateFlow<ActionPlan?> = brain.pendingConfirmationPlan

    val routines: StateFlow<List<RoutineItem>> = repository.allRoutines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memories: StateFlow<List<MemoryItem>> = repository.allMemory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isAccessibilityConnected: StateFlow<Boolean> = JarvisAccessibilityService.isServiceConnected
    val isNotificationListenerConnected: StateFlow<Boolean> = JarvisNotificationListenerService.isListenerConnected

    val voiceManager = VoiceManager(application) { voiceText ->
        submitUserInput(voiceText)
    }

    val jarvisStatus: StateFlow<JarvisVoiceStatus> = voiceManager.status
    val isListening: StateFlow<Boolean> = voiceManager.isListening
    val isSpeaking: StateFlow<Boolean> = voiceManager.isSpeaking
    val rmsAmplitude: StateFlow<Float> = voiceManager.rmsAmplitude
    val partialSpeechText: StateFlow<String> = voiceManager.partialText
    val speechError: StateFlow<String?> = voiceManager.speechError

    val isWakeWordEnabled: StateFlow<Boolean> = voiceManager.isWakeWordEnabled.asStateFlow()
    val isAlwaysListening: StateFlow<Boolean> = voiceManager.isAlwaysListening.asStateFlow()
    val voiceResponsesEnabled: StateFlow<Boolean> = voiceManager.voiceResponsesEnabled.asStateFlow()

    private val _pendingAttachment = MutableStateFlow<MediaAttachment?>(null)
    val pendingAttachment: StateFlow<MediaAttachment?> = _pendingAttachment.asStateFlow()

    private val _userName = MutableStateFlow("Alex")
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _aiPersonality = MutableStateFlow("Stark Classic (Confident, Polite & Witty)")
    val aiPersonality: StateFlow<String> = _aiPersonality.asStateFlow()

    private val _voicePitch = MutableStateFlow(0.95f)
    val voicePitch: StateFlow<Float> = _voicePitch.asStateFlow()

    private val _voiceRate = MutableStateFlow(1.0f)
    val voiceRate: StateFlow<Float> = _voiceRate.asStateFlow()

    private val _useCloudAi = MutableStateFlow(true)
    val useCloudAi: StateFlow<Boolean> = _useCloudAi.asStateFlow()

    private val _customApiKey = MutableStateFlow("")
    val customApiKey: StateFlow<String> = _customApiKey.asStateFlow()

    init {
        brain.voiceManager = voiceManager
        viewModelScope.launch {
            repository.allMemory.collect { memories ->
                val saved = memories.find { it.key == "user_name" || it.key == "preferred_name" }?.value
                if (!saved.isNullOrBlank()) {
                    _userName.value = saved
                    voiceManager.userName = saved
                }
            }
        }
    }

    fun updateUserName(name: String) {
        val trimmed = name.trim()
        _userName.value = trimmed
        voiceManager.userName = trimmed
        viewModelScope.launch {
            repository.saveMemory(
                MemoryItem(key = "user_name", value = trimmed, category = "identity")
            )
        }
    }

    fun submitUserInput(input: String) {
        val attachment = _pendingAttachment.value
        _pendingAttachment.value = null
        brain.processUserInput(input, attachment)
    }

    fun submitMultimodalInput(input: String, attachment: MediaAttachment?) {
        _pendingAttachment.value = null
        brain.processUserInput(input, attachment)
    }

    fun setPendingAttachment(attachment: MediaAttachment?) {
        _pendingAttachment.value = attachment
    }

    fun clearPendingAttachment() {
        _pendingAttachment.value = null
    }

    fun stopCurrentOperation() {
        brain.stopCurrentOperation()
    }

    fun startVoice() {
        voiceManager.startActiveListening()
    }

    fun stopVoice() {
        voiceManager.stopListening()
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    fun confirmPendingPlan() {
        brain.confirmPendingPlan()
    }

    fun cancelPendingPlan() {
        brain.cancelPendingPlan()
    }

    fun clearConversation() {
        brain.clearConversation()
    }

    fun setWakeWordEnabled(enabled: Boolean) {
        voiceManager.isWakeWordEnabled.value = enabled
        if (enabled) {
            voiceManager.startWakeWordMonitoring()
            if (isAlwaysListening.value) {
                JarvisVoiceService.start(getApplication())
            }
        } else {
            voiceManager.stopListening()
            JarvisVoiceService.stop(getApplication())
        }
    }

    fun setAlwaysListening(enabled: Boolean) {
        voiceManager.isAlwaysListening.value = enabled
        if (enabled && isWakeWordEnabled.value) {
            JarvisVoiceService.start(getApplication())
        } else if (!enabled) {
            JarvisVoiceService.stop(getApplication())
        }
    }

    fun setVoiceResponsesEnabled(enabled: Boolean) {
        voiceManager.voiceResponsesEnabled.value = enabled
    }

    fun setAiPersonality(personality: String) {
        _aiPersonality.value = personality
        brain.geminiProvider.personalityPrompt = personality
    }

    fun toggleCloudAi(enabled: Boolean) {
        _useCloudAi.value = enabled
        brain.useCloudAi = enabled
    }

    fun updateApiKey(key: String) {
        _customApiKey.value = key
        brain.geminiProvider.updateApiKey(key.takeIf { it.isNotBlank() })
    }

    fun updatePitch(pitch: Float) {
        _voicePitch.value = pitch
        voiceManager.pitch = pitch
    }

    fun updateRate(rate: Float) {
        _voiceRate.value = rate
        voiceManager.speechRate = rate
    }

    fun testVoice() {
        voiceManager.speak("At your service, Sir. Audio synthesis is functioning at peak efficiency.")
    }

    fun triggerRoutine(routine: RoutineItem) {
        val lines = routine.stepsRaw.split("\n").filter { it.isNotBlank() }
        if (lines.isNotEmpty()) {
            submitUserInput(routine.triggerPhrase)
        }
    }

    fun saveRoutine(name: String, desc: String, trigger: String, steps: String) {
        viewModelScope.launch {
            repository.saveRoutine(
                RoutineItem(
                    name = name,
                    description = desc,
                    triggerPhrase = trigger,
                    stepsRaw = steps
                )
            )
        }
    }

    fun deleteRoutine(id: Int) {
        viewModelScope.launch {
            repository.deleteRoutine(id)
        }
    }

    fun saveMemory(key: String, value: String, category: String) {
        viewModelScope.launch {
            repository.saveMemory(
                MemoryItem(key = key, value = value, category = category)
            )
        }
    }

    fun deleteMemory(id: Int) {
        viewModelScope.launch {
            repository.deleteMemory(id)
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}
