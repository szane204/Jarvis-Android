package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavyCardBorder
import com.example.ui.theme.DeepVoidBlack
import com.example.ui.theme.HologramAmber
import com.example.ui.theme.HologramGreen
import com.example.ui.theme.HologramRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextCyberDim
import com.example.ui.theme.TextCyberWhite

@Composable
fun SettingsScreen(
    userName: String,
    onUpdateUserName: (String) -> Unit,
    isWakeWordEnabled: Boolean,
    onToggleWakeWord: (Boolean) -> Unit,
    isAlwaysListening: Boolean,
    onToggleAlwaysListening: (Boolean) -> Unit,
    voiceResponsesEnabled: Boolean,
    onToggleVoiceResponses: (Boolean) -> Unit,
    aiPersonality: String,
    onSelectPersonality: (String) -> Unit,
    useCloudAi: Boolean,
    onToggleCloudAi: (Boolean) -> Unit,
    currentApiKey: String,
    onUpdateApiKey: (String) -> Unit,
    voicePitch: Float,
    onUpdatePitch: (Float) -> Unit,
    voiceRate: Float,
    onUpdateRate: (Float) -> Unit,
    onTestVoice: () -> Unit,
    onClearConversation: () -> Unit,
    onOpenMicSettings: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    hasMicPermission: Boolean,
    isAccessibilityEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    var apiKeyInput by remember(currentApiKey) { mutableStateOf(currentApiKey) }
    var showApiKey by remember { mutableStateOf(false) }

    val personalities = listOf(
        "Stark Classic (Confident, Polite & Witty)",
        "Tactical Operative (Direct & Concise)",
        "Minimalist Assistant (Short & Objective)"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepVoidBlack)
            .padding(16.dp)
    ) {
        Text(
            text = "JARVIS SYSTEM SETTINGS",
            color = NeonCyan,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
        Text(
            text = "Voice engine, wake word, personality, and permissions",
            color = TextCyberDim,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // 0. Preferred Name
            item {
                SettingsSectionCard(title = "PREFERRED NAME") {
                    Text(
                        text = "Assistant: JARVIS // Callsign Management",
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = userName,
                        onValueChange = onUpdateUserName,
                        label = { Text("Preferred Name (e.g. Alex)", fontSize = 11.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkNavyCardBorder,
                            focusedTextColor = TextCyberWhite,
                            unfocusedTextColor = TextCyberWhite
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("preferred_name_settings_field")
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "JARVIS greeting: \"Yes, ${userName.ifBlank { "Sir" }}?\"",
                            color = TextCyberDim,
                            fontSize = 11.sp
                        )
                        if (userName.isNotBlank()) {
                            OutlinedButton(
                                onClick = { onUpdateUserName("") },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Delete Name", color = HologramRed, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            // 1. Wake Word & Voice Activation
            item {
                SettingsSectionCard(title = "VOICE ACTIVATION & WAKE PHRASE") {
                    // Wake Word Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Wake Word: \"Hey JARVIS\"",
                                color = TextCyberWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Wakes up automatically when you say \"Hey JARVIS\" without pressing buttons.",
                                color = TextCyberDim,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = isWakeWordEnabled,
                            onCheckedChange = onToggleWakeWord,
                            colors = switchColors(),
                            modifier = Modifier.testTag("wake_word_toggle")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Always Listening Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Always Listening (Follow-up Mode)",
                                color = TextCyberWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Listens for natural follow-up questions after speaking without needing to re-trigger.",
                                color = TextCyberDim,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = isAlwaysListening,
                            onCheckedChange = onToggleAlwaysListening,
                            colors = switchColors(),
                            modifier = Modifier.testTag("always_listening_toggle")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Spoken Voice Responses
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Voice Responses (TTS)",
                                color = TextCyberWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Speaks all answers aloud naturally via Android Text-to-Speech.",
                                color = TextCyberDim,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = voiceResponsesEnabled,
                            onCheckedChange = onToggleVoiceResponses,
                            colors = switchColors(),
                            modifier = Modifier.testTag("voice_responses_toggle")
                        )
                    }
                }
            }

            // 2. AI Personality
            item {
                SettingsSectionCard(title = "AI PERSONALITY & CONVERSATION") {
                    Text(
                        text = "Current Personality:",
                        color = TextCyberDim,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    personalities.forEach { p ->
                        val isSelected = aiPersonality == p
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) NeonCyan.copy(alpha = 0.15f) else DarkNavyCard)
                                .border(1.dp, if (isSelected) NeonCyan else DarkNavyCardBorder, RoundedCornerShape(8.dp))
                                .clickable { onSelectPersonality(p) }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) NeonCyan else TextCyberDim)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = p,
                                    color = if (isSelected) NeonCyan else TextCyberWhite,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Gemini Conversational Cloud",
                                color = TextCyberWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (useCloudAi) "Gemini 3.5 Flash Active" else "Offline Rule Engine Active",
                                color = TextCyberDim,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = useCloudAi,
                            onCheckedChange = onToggleCloudAi,
                            colors = switchColors()
                        )
                    }

                    if (useCloudAi) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = apiKeyInput,
                            onValueChange = {
                                apiKeyInput = it
                                onUpdateApiKey(it)
                            },
                            placeholder = { Text("Custom Gemini API Key (optional override)", fontSize = 11.sp) },
                            singleLine = true,
                            visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(onClick = { showApiKey = !showApiKey }) {
                                    Icon(
                                        imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = "Toggle visibility",
                                        tint = TextCyberDim
                                    )
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = DarkNavyCardBorder,
                                focusedTextColor = TextCyberWhite,
                                unfocusedTextColor = TextCyberWhite
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("api_key_settings_field")
                        )
                    }
                }
            }

            // 3. Speech Tuning (Speed & Pitch)
            item {
                SettingsSectionCard(title = "VOICE SYNTHESIS SPEED & PITCH") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Speech Rate: ${String.format("%.2f", voiceRate)}x",
                            color = TextCyberWhite,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Button(
                            onClick = onTestVoice,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = DeepVoidBlack),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Test Voice", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Slider(
                        value = voiceRate,
                        onValueChange = onUpdateRate,
                        valueRange = 0.7f..1.4f,
                        colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Pitch: ${String.format("%.2f", voicePitch)}",
                        color = TextCyberWhite,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Slider(
                        value = voicePitch,
                        onValueChange = onUpdatePitch,
                        valueRange = 0.7f..1.3f,
                        colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                    )
                }
            }

            // 4. Conversation History Management
            item {
                SettingsSectionCard(title = "CONVERSATION HISTORY") {
                    Text(
                        text = "Clear recent conversation memory and message history.",
                        color = TextCyberDim,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = onClearConversation,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = HologramRed),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, HologramRed.copy(alpha = 0.6f)),
                        modifier = Modifier.fillMaxWidth().testTag("clear_conversation_button")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Clear Current Conversation", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }
            }

            // 5. System Permissions (Microphone & Accessibility)
            item {
                SettingsSectionCard(title = "SYSTEM PERMISSIONS") {
                    PermissionStatusRow(
                        title = "Microphone Permission",
                        isGranted = hasMicPermission,
                        onAction = onOpenMicSettings,
                        actionLabel = "App Settings"
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    PermissionStatusRow(
                        title = "JARVIS Accessibility Service",
                        isGranted = isAccessibilityEnabled,
                        onAction = onOpenAccessibilitySettings,
                        actionLabel = "Accessibility"
                    )
                }
            }

            // 6. About JARVIS
            item {
                SettingsSectionCard(title = "ABOUT JARVIS") {
                    Text(
                        text = "JARVIS AI Voice OS",
                        color = TextCyberWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Version 2.0 (Stark Edition) // 120 FPS High Refresh Engine",
                        color = NeonCyan,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Fully voice-controlled Android assistant capable of natural multi-turn conversations, follow-up reasoning, screen navigation, and phone device automation.",
                        color = TextCyberDim,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkNavyCard)
            .border(1.dp, DarkNavyCardBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Column {
            Text(
                text = title,
                color = NeonCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun PermissionStatusRow(
    title: String,
    isGranted: Boolean,
    onAction: () -> Unit,
    actionLabel: String
) {
    val statusColor = if (isGranted) HologramGreen else HologramAmber
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(statusColor)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                color = TextCyberWhite,
                fontSize = 12.sp
            )
        }

        OutlinedButton(
            onClick = onAction,
            shape = RoundedCornerShape(6.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text(
                text = if (isGranted) "Granted" else actionLabel,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = if (isGranted) HologramGreen else HologramAmber
            )
        }
    }
}

@Composable
private fun switchColors() = SwitchDefaults.colors(
    checkedThumbColor = DeepVoidBlack,
    checkedTrackColor = NeonCyan,
    uncheckedThumbColor = TextCyberDim,
    uncheckedTrackColor = DarkNavyCard
)
