package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.JarvisState
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavyCardBorder
import com.example.ui.theme.DeepVoidBlack
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.HologramAmber
import com.example.ui.theme.HologramGreen
import com.example.ui.theme.HologramRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextCyberWhite
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JarvisHologramAvatar(
    state: JarvisState,
    rmsAmplitude: Float,
    isSpeaking: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 210.dp,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "jarvis_avatar_anim")

    // 1. Ambient breathing pulse
    val breathingPulse by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "avatar_breath"
    )

    // 2. Continuous HUD rotation (counter-clockwise & clockwise)
    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    JarvisState.THINKING, JarvisState.GENERATING, JarvisState.GENERATING_IMAGE, JarvisState.GENERATING_VIDEO -> 2200
                    JarvisState.LISTENING -> 4000
                    JarvisState.SPEAKING -> 5000
                    else -> 9000
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "avatar_ring_rotation"
    )

    // 3. Speech lip sync waveform phase (moves mouth and vocal rings)
    val speechPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "avatar_speech_sync"
    )

    // 4. Eyelid blink animation (periodic blink every 3.5s)
    val blinkProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "avatar_blink"
    )

    // 5. Vertical holographic scan line
    val scanLineY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "avatar_scanline"
    )

    // Dynamic state accent colors
    val themeColor by animateColorAsState(
        targetValue = when (state) {
            JarvisState.LISTENING -> HologramGreen
            JarvisState.THINKING -> HologramAmber
            JarvisState.SPEAKING -> ElectricBlue
            JarvisState.GENERATING, JarvisState.GENERATING_IMAGE, JarvisState.GENERATING_VIDEO -> HologramAmber
            JarvisState.ERROR -> HologramRed
            else -> NeonCyan
        },
        label = "avatar_theme_color"
    )

    val hudLabel = when (state) {
        JarvisState.LISTENING -> "LISTENING"
        JarvisState.THINKING -> "THINKING"
        JarvisState.SPEAKING -> "SPEAKING"
        JarvisState.GENERATING_IMAGE -> "GENERATING IMAGE"
        JarvisState.GENERATING_VIDEO -> "GENERATING VIDEO"
        JarvisState.GENERATING -> "GENERATING"
        JarvisState.ERROR -> "ERROR"
        JarvisState.EXECUTING -> "EXECUTING"
        JarvisState.IDLE -> "IDLE"
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .clickable { onClick() }
                .testTag("jarvis_avatar_element"),
            contentAlignment = Alignment.Center
        ) {
            // Core Holographic Face Asset (Base visual foundation)
            Image(
                painter = painterResource(id = R.drawable.jarvis_avatar_base),
                contentDescription = "JARVIS Holographic AI Face",
                modifier = Modifier
                    .size(size * 0.82f)
                    .clip(CircleShape)
                    .border(1.5.dp, themeColor.copy(alpha = 0.6f), CircleShape),
                contentScale = ContentScale.Crop
            )

            // Dynamic Procedural Hologram Overlay (HUD, eyes, mouth sync & waveform rings)
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(this.size.width / 2f, this.size.height / 2f)
                val baseRadius = this.size.minDimension / 2f * 0.88f * breathingPulse

                // A. Outer Atmospheric Glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            themeColor.copy(alpha = 0.28f),
                            themeColor.copy(alpha = 0.08f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = baseRadius * 1.15f
                    ),
                    radius = baseRadius * 1.15f,
                    center = center
                )

                // B. Voice Reactive Waveform Ring (Expands with user audio in LISTENING mode)
                val reactiveRadius = if (state == JarvisState.LISTENING) {
                    baseRadius + (rmsAmplitude * 24.dp.toPx())
                } else if (isSpeaking || state == JarvisState.SPEAKING) {
                    baseRadius + (abs(sin(speechPhase)) * 12.dp.toPx())
                } else {
                    baseRadius
                }

                drawCircle(
                    color = themeColor.copy(alpha = 0.45f),
                    radius = reactiveRadius,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                // C. Outer Rotating Segmented HUD Reticle
                rotate(degrees = ringRotation, pivot = center) {
                    val segmentCount = 12
                    val sweep = 360f / segmentCount
                    for (i in 0 until segmentCount) {
                        val startAngle = i * sweep
                        drawArc(
                            color = themeColor.copy(alpha = if (i % 2 == 0) 0.65f else 0.25f),
                            startAngle = startAngle + 4f,
                            sweepAngle = sweep - 8f,
                            useCenter = false,
                            topLeft = Offset(center.x - baseRadius * 1.05f, center.y - baseRadius * 1.05f),
                            size = Size(baseRadius * 2.1f, baseRadius * 2.1f),
                            style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }

                // D. Inner Counter-Rotating Precision Calibration Ring
                rotate(degrees = -ringRotation * 1.4f, pivot = center) {
                    val innerRadius = baseRadius * 0.94f
                    val tickCount = 24
                    for (i in 0 until tickCount) {
                        val angle = (i * 360f / tickCount) * (PI.toFloat() / 180f)
                        val startP = Offset(center.x + innerRadius * cos(angle), center.y + innerRadius * sin(angle))
                        val endP = Offset(center.x + (innerRadius + 4.dp.toPx()) * cos(angle), center.y + (innerRadius + 4.dp.toPx()) * sin(angle))
                        drawLine(
                            color = themeColor.copy(alpha = 0.5f),
                            start = startP,
                            end = endP,
                            strokeWidth = 1.dp.toPx()
                        )
                    }
                }

                // E. Real-Time Speech Mouth Sync Animation (Procedural digital mouth movements)
                if (isSpeaking || state == JarvisState.SPEAKING) {
                    val mouthCenterY = center.y + baseRadius * 0.42f
                    val mouthWidth = baseRadius * 0.32f
                    // Mouth opening scales with speech sine wave modulation
                    val mouthOpenHeight = (sin(speechPhase * 2f).coerceAtLeast(0f) * 8.dp.toPx()) + 2.dp.toPx()

                    val mouthPath = Path().apply {
                        moveTo(center.x - mouthWidth / 2f, mouthCenterY)
                        quadraticTo(center.x, mouthCenterY - mouthOpenHeight, center.x + mouthWidth / 2f, mouthCenterY)
                        quadraticTo(center.x, mouthCenterY + mouthOpenHeight, center.x - mouthWidth / 2f, mouthCenterY)
                        close()
                    }

                    drawPath(
                        path = mouthPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(ElectricBlue.copy(alpha = 0.8f), NeonCyan.copy(alpha = 0.9f))
                        )
                    )
                }

                // F. Intelligent Holographic Eye Blink / Scanning Modulation
                // Blink occurs momentarily when blinkProgress is between 0.92 and 0.97
                val isBlinking = blinkProgress in 0.92f..0.97f
                val eyeY = center.y - baseRadius * 0.12f
                val eyeSpacing = baseRadius * 0.28f
                val eyeWidth = baseRadius * 0.18f

                if (isBlinking) {
                    // Closed eye scan line
                    drawLine(
                        color = themeColor,
                        start = Offset(center.x - eyeSpacing - eyeWidth / 2f, eyeY),
                        end = Offset(center.x - eyeSpacing + eyeWidth / 2f, eyeY),
                        strokeWidth = 2.dp.toPx()
                    )
                    drawLine(
                        color = themeColor,
                        start = Offset(center.x + eyeSpacing - eyeWidth / 2f, eyeY),
                        end = Offset(center.x + eyeSpacing + eyeWidth / 2f, eyeY),
                        strokeWidth = 2.dp.toPx()
                    )
                } else if (state == JarvisState.LISTENING) {
                    // Dilated glowing eyes focusing on user voice
                    drawCircle(
                        color = HologramGreen.copy(alpha = 0.7f),
                        radius = 4.dp.toPx() + (rmsAmplitude * 3.dp.toPx()),
                        center = Offset(center.x - eyeSpacing, eyeY)
                    )
                    drawCircle(
                        color = HologramGreen.copy(alpha = 0.7f),
                        radius = 4.dp.toPx() + (rmsAmplitude * 3.dp.toPx()),
                        center = Offset(center.x + eyeSpacing, eyeY)
                    )
                }

                // G. Horizontal Holographic Scan Line Sweep
                val scanY = (center.y - baseRadius) + (scanLineY * baseRadius * 2f)
                drawLine(
                    brush = Brush.horizontalGradient(
                        colors = listOf(Color.Transparent, themeColor.copy(alpha = 0.45f), Color.Transparent),
                        startX = center.x - baseRadius * 0.8f,
                        endX = center.x + baseRadius * 0.8f
                    ),
                    start = Offset(center.x - baseRadius * 0.8f, scanY),
                    end = Offset(center.x + baseRadius * 0.8f, scanY),
                    strokeWidth = 1.5.dp.toPx()
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Futuristic Holographic State Indicator HUD Badge
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(DarkNavyCard)
                .border(1.dp, themeColor.copy(alpha = 0.7f), CircleShape)
                .padding(horizontal = 14.dp, vertical = 4.dp)
        ) {
            Text(
                text = hudLabel,
                color = themeColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.2.sp
            )
        }
    }
}
