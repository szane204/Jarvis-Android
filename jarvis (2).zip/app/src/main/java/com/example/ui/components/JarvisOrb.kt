package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.JarvisState
import com.example.ui.theme.ArcReactorCore
import com.example.ui.theme.ArcReactorOuter
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.HologramAmber
import com.example.ui.theme.HologramGreen
import com.example.ui.theme.HologramRed
import com.example.ui.theme.NeonCyan
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JarvisOrb(
    state: JarvisState,
    rmsAmplitude: Float = 0f,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "jarvis_orb_transition")

    // Slow rotation for outer tech ring
    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_rot"
    )

    // Reverse fast rotation for inner reticle ring
    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner_rot"
    )

    // Idle breathing pulse
    val breathingPulse by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing"
    )

    // Waveform phase
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.2831f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave"
    )

    // Dynamic color depending on state
    val mainGlowColor = when (state) {
        JarvisState.IDLE -> NeonCyan
        JarvisState.LISTENING -> HologramGreen
        JarvisState.THINKING -> HologramAmber
        JarvisState.GENERATING, JarvisState.GENERATING_IMAGE, JarvisState.GENERATING_VIDEO -> HologramAmber
        JarvisState.EXECUTING -> ElectricBlue
        JarvisState.SPEAKING -> NeonCyan
        JarvisState.ERROR -> HologramRed
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = this.size.minDimension / 2f * 0.72f

            // Dynamic scale adjustment based on state and microphone amplitude
            val scale = when (state) {
                JarvisState.LISTENING -> 1f + (rmsAmplitude * 0.35f)
                JarvisState.SPEAKING -> 1f + (sin(wavePhase) * 0.12f).coerceAtLeast(0f)
                JarvisState.THINKING, JarvisState.GENERATING, JarvisState.GENERATING_IMAGE, JarvisState.GENERATING_VIDEO -> 1.05f
                JarvisState.EXECUTING -> 1f + (sin(wavePhase * 2) * 0.08f)
                JarvisState.IDLE, JarvisState.ERROR -> breathingPulse
            }
            val radius = baseRadius * scale

            // 1. Soft atmospheric outer aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        mainGlowColor.copy(alpha = 0.35f),
                        mainGlowColor.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = radius * 1.55f
                ),
                radius = radius * 1.55f,
                center = center
            )

            // 2. Outer segmented tech ring
            rotate(degrees = outerRotation, pivot = center) {
                drawCircle(
                    color = mainGlowColor.copy(alpha = 0.4f),
                    radius = radius * 1.18f,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
                )

                // 8 arc ticks
                for (i in 0 until 8) {
                    val angle = (i * 45f) * (Math.PI / 180f).toFloat()
                    val startR = radius * 1.14f
                    val endR = radius * 1.25f
                    val start = Offset(center.x + cos(angle) * startR, center.y + sin(angle) * startR)
                    val end = Offset(center.x + cos(angle) * endR, center.y + sin(angle) * endR)
                    drawLine(
                        color = mainGlowColor.copy(alpha = 0.8f),
                        start = start,
                        end = end,
                        strokeWidth = 2.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // 3. Counter-rotating inner reticle with tick notches
            rotate(degrees = innerRotation, pivot = center) {
                drawCircle(
                    color = ArcReactorOuter.copy(alpha = 0.5f),
                    radius = radius * 0.95f,
                    center = center,
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                )

                // 16 mini tick notches
                for (i in 0 until 16) {
                    val angle = (i * 22.5f) * (Math.PI / 180f).toFloat()
                    val r1 = radius * 0.90f
                    val r2 = radius * 0.95f
                    val p1 = Offset(center.x + cos(angle) * r1, center.y + sin(angle) * r1)
                    val p2 = Offset(center.x + cos(angle) * r2, center.y + sin(angle) * r2)
                    drawLine(
                        color = NeonCyan.copy(alpha = 0.6f),
                        start = p1,
                        end = p2,
                        strokeWidth = 1.5.dp.toPx()
                    )
                }
            }

            // 4. Center Arc Reactor glowing sphere
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        ArcReactorCore.copy(alpha = 0.95f),
                        mainGlowColor.copy(alpha = 0.85f),
                        ElectricBlue.copy(alpha = 0.55f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = radius * 0.70f
                ),
                radius = radius * 0.70f,
                center = center
            )

            // 5. Reactive Waveform (for SPEAKING & THINKING & LISTENING)
            if (state == JarvisState.SPEAKING || state == JarvisState.LISTENING || state == JarvisState.EXECUTING) {
                val barCount = 24
                val angleStep = 360f / barCount
                for (i in 0 until barCount) {
                    val angleDeg = i * angleStep
                    val angleRad = Math.toRadians(angleDeg.toDouble()).toFloat()
                    val waveAmp = sin(angleRad * 3 + wavePhase) * (if (state == JarvisState.LISTENING) (rmsAmplitude * 35f + 10f) else 18f)
                    val barInner = radius * 0.72f
                    val barOuter = (radius * 0.72f + waveAmp.coerceAtLeast(4f))

                    val start = Offset(center.x + cos(angleRad) * barInner, center.y + sin(angleRad) * barInner)
                    val end = Offset(center.x + cos(angleRad) * barOuter, center.y + sin(angleRad) * barOuter)

                    drawLine(
                        color = mainGlowColor,
                        start = start,
                        end = end,
                        strokeWidth = 2.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // 6. Center holographic core dot
            drawCircle(
                color = ArcReactorCore,
                radius = radius * 0.16f,
                center = center
            )
        }
    }
}
