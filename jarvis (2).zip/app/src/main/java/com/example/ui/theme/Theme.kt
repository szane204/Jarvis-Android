package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val JarvisColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = DeepVoidBlack,
    primaryContainer = DarkNavyCard,
    onPrimaryContainer = NeonCyan,
    secondary = ElectricBlue,
    onSecondary = TextCyberWhite,
    secondaryContainer = DarkNavyCardBorder,
    onSecondaryContainer = TextCyberWhite,
    tertiary = HologramGreen,
    onTertiary = DeepVoidBlack,
    background = DeepVoidBlack,
    onBackground = TextCyberWhite,
    surface = DarkNavySurface,
    onSurface = TextCyberWhite,
    surfaceVariant = DarkNavyCard,
    onSurfaceVariant = TextCyberDim,
    error = HologramRed,
    onError = TextCyberWhite,
    outline = DarkNavyCardBorder
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = DeepVoidBlack.toArgb()
                window.navigationBarColor = DeepVoidBlack.toArgb()
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = false
                    isAppearanceLightNavigationBars = false
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = JarvisColorScheme,
        typography = Typography,
        content = content
    )
}
