package com.example.ui.screens

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavyCardBorder
import com.example.ui.theme.DeepVoidBlack
import com.example.ui.theme.HologramAmber
import com.example.ui.theme.HologramGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextCyberDim
import com.example.ui.theme.TextCyberWhite

@Composable
fun DiagnosticsScreen(
    isAccessibilityEnabled: Boolean,
    isNotificationListenerEnabled: Boolean,
    hasRecordAudioPermission: Boolean,
    onOpenAccessibilitySettings: () -> Unit,
    onOpenNotificationSettings: () -> Unit,
    onRequestRecordAudioPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepVoidBlack)
            .padding(16.dp)
    ) {
        Text(
            text = "SYSTEM TELEMETRY & PERMISSIONS",
            color = NeonCyan,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
        Text(
            text = "Verification of Android operating layer permissions & sensors",
            color = TextCyberDim,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // 1. Accessibility Service Card
            item {
                PermissionCard(
                    title = "ACCESSIBILITY OPERATING SERVICE",
                    isGranted = isAccessibilityEnabled,
                    statusText = if (isAccessibilityEnabled) "SERVICE ACTIVE & RUNNING" else "SERVICE NOT DETECTED",
                    description = "Required for UI actions: pressing Back, Home, Recent Apps, scrolling, tapping buttons by text (e.g. 'tap Continue'), and taking screenshots.",
                    actionLabel = "Open Accessibility Settings",
                    onAction = onOpenAccessibilitySettings,
                    testTag = "enable_accessibility_button"
                )
            }

            // 2. Notification Listener Card
            item {
                PermissionCard(
                    title = "NOTIFICATION ASSISTANT SERVICE",
                    isGranted = isNotificationListenerEnabled,
                    statusText = if (isNotificationListenerEnabled) "ACCESS GRANTED" else "ACCESS NOT GRANTED",
                    description = "Required for 'Read my notifications' and 'Summarize notifications' across WhatsApp, Gmail, SMS, and other apps.",
                    actionLabel = "Open Notification Access Settings",
                    onAction = onOpenNotificationSettings,
                    testTag = "enable_notifications_button"
                )
            }

            // 3. Audio / Microphone Permission Card
            item {
                PermissionCard(
                    title = "MICROPHONE & SPEECH INPUT",
                    isGranted = hasRecordAudioPermission,
                    statusText = if (hasRecordAudioPermission) "AUDIO RECORDING PERMITTED" else "RECORD AUDIO REQUIRED",
                    description = "Required for hands-free voice commands and speech recognition.",
                    actionLabel = "Grant Microphone Permission",
                    onAction = onRequestRecordAudioPermission,
                    testTag = "grant_mic_button"
                )
            }

            // 4. Device Diagnostics Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkNavyCard)
                        .border(1.dp, DarkNavyCardBorder, RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(
                            text = "DEVICE ARCHITECTURE",
                            color = NeonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        DiagnosticRow("Android Version", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                        DiagnosticRow("Device Model", "${Build.MANUFACTURER.uppercase()} ${Build.MODEL}")
                        DiagnosticRow("Security Core", "Android Keystore & Sandbox Safe")
                        DiagnosticRow("Storage Framework", "Android Storage Access Framework")
                        DiagnosticRow("AI Engine", "Gemini 3.5 Flash / Local Rule Planner")
                    }
                }
            }
        }
    }
}

@Composable
private fun DiagnosticRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextCyberDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = TextCyberWhite, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun PermissionCard(
    title: String,
    isGranted: Boolean,
    statusText: String,
    description: String,
    actionLabel: String,
    onAction: () -> Unit,
    testTag: String
) {
    val statusColor = if (isGranted) HologramGreen else HologramAmber
    val icon: ImageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkNavyCard)
            .border(1.dp, if (isGranted) DarkNavyCardBorder else HologramAmber.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    color = NeonCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 0.5.sp
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = statusText,
                        color = statusColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = description,
                color = TextCyberDim,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            if (!isGranted) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onAction,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = HologramAmber,
                        contentColor = DeepVoidBlack
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag(testTag)
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = actionLabel,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
