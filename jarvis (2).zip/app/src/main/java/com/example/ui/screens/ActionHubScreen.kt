package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Screenshot
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PlanStep
import com.example.model.ToolResult
import com.example.tools.JarvisToolRegistry
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavyCardBorder
import com.example.ui.theme.DeepVoidBlack
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.HologramAmber
import com.example.ui.theme.HologramGreen
import com.example.ui.theme.HologramRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextCyberDim
import com.example.ui.theme.TextCyberWhite

@Composable
fun ActionHubScreen(
    toolRegistry: JarvisToolRegistry,
    modifier: Modifier = Modifier
) {
    var lastExecutionResult by remember { mutableStateOf<ToolResult?>(null) }

    fun executeQuickTool(toolName: String, params: Map<String, String> = emptyMap()) {
        val step = PlanStep(
            id = System.currentTimeMillis().toString(),
            title = "Manual Trigger $toolName",
            toolName = toolName,
            params = params
        )
        lastExecutionResult = toolRegistry.execute(step)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepVoidBlack)
            .padding(16.dp)
    ) {
        Text(
            text = "ACTION COMMAND HUB",
            color = NeonCyan,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
        Text(
            text = "Direct operational triggers for Android system functions",
            color = TextCyberDim,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Last execution status banner
        if (lastExecutionResult != null) {
            val res = lastExecutionResult!!
            val statusColor = if (res.success) HologramGreen else HologramAmber
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkNavyCard)
                    .border(1.dp, statusColor.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "EXECUTION RESULT // ${res.action.uppercase()}",
                            color = statusColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = res.result,
                        color = TextCyberWhite,
                        fontSize = 12.sp
                    )
                    if (res.limitationNote != null) {
                        Text(
                            text = "Note: ${res.limitationNote}",
                            color = HologramAmber,
                            fontSize = 11.sp
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // Category: Screen & UI Automation (Accessibility)
            item {
                ActionCategoryCard(
                    title = "SCREEN & ACCESSIBILITY CONTROLS",
                    actions = listOf(
                        ActionItem("Go Back", Icons.AutoMirrored.Filled.ArrowBack) { executeQuickTool("press_back") },
                        ActionItem("Go Home", Icons.Default.Home) { executeQuickTool("go_home") },
                        ActionItem("Recent Apps", Icons.Default.Apps) { executeQuickTool("recent_apps") },
                        ActionItem("Screenshot", Icons.Default.Screenshot) { executeQuickTool("take_screenshot") },
                        ActionItem("Scroll Down", Icons.Default.TouchApp) { executeQuickTool("scroll", mapOf("direction" to "down")) },
                        ActionItem("Scroll Up", Icons.Default.TouchApp) { executeQuickTool("scroll", mapOf("direction" to "up")) }
                    )
                )
            }

            // Category: App Launching
            item {
                ActionCategoryCard(
                    title = "APP ECOSYSTEM LAUNCHER",
                    actions = listOf(
                        ActionItem("Instagram", Icons.Default.CameraAlt) { executeQuickTool("open_app", mapOf("app" to "Instagram")) },
                        ActionItem("WhatsApp", Icons.Default.Phone) { executeQuickTool("open_app", mapOf("app" to "WhatsApp")) },
                        ActionItem("YouTube", Icons.Default.Search) { executeQuickTool("open_app", mapOf("app" to "YouTube")) },
                        ActionItem("Chrome", Icons.Default.Search) { executeQuickTool("open_app", mapOf("app" to "Chrome")) },
                        ActionItem("Gmail", Icons.Default.Email) { executeQuickTool("open_app", mapOf("app" to "Gmail")) },
                        ActionItem("Settings", Icons.Default.Settings) { executeQuickTool("open_app", mapOf("app" to "Settings")) },
                        ActionItem("Camera", Icons.Default.CameraAlt) { executeQuickTool("open_app", mapOf("app" to "Camera")) }
                    )
                )
            }

            // Category: Communications
            item {
                ActionCategoryCard(
                    title = "COMMUNICATIONS & MESSAGING",
                    actions = listOf(
                        ActionItem("Draft Email", Icons.Default.Email) {
                            executeQuickTool("draft_email", mapOf("recipient" to "contact@example.com", "body" to "Hello from JARVIS", "subject" to "JARVIS Update"))
                        },
                        ActionItem("WhatsApp Web", Icons.Default.Phone) {
                            executeQuickTool("send_whatsapp", mapOf("message" to "Hello from JARVIS"))
                        },
                        ActionItem("Send SMS", Icons.Default.Phone) {
                            executeQuickTool("send_sms", mapOf("body" to "JARVIS test message"))
                        }
                    )
                )
            }

            // Category: Device & Hardware Controls
            item {
                ActionCategoryCard(
                    title = "DEVICE & SYSTEM CONTROLS",
                    actions = listOf(
                        ActionItem("Wi-Fi Panel", Icons.Default.Wifi) { executeQuickTool("toggle_wifi") },
                        ActionItem("Bluetooth", Icons.Default.Bluetooth) { executeQuickTool("toggle_bluetooth") },
                        ActionItem("Set Alarm 7 AM", Icons.Default.Alarm) { executeQuickTool("set_alarm", mapOf("hour" to "7", "minute" to "0")) },
                        ActionItem("Timer 10 Min", Icons.Default.Alarm) { executeQuickTool("set_timer", mapOf("minutes" to "10")) },
                        ActionItem("Volume Up", Icons.AutoMirrored.Filled.VolumeUp) { executeQuickTool("adjust_volume", mapOf("direction" to "up")) },
                        ActionItem("Volume Down", Icons.AutoMirrored.Filled.VolumeUp) { executeQuickTool("adjust_volume", mapOf("direction" to "down")) },
                        ActionItem("Notifications", Icons.Default.Notifications) { executeQuickTool("read_notifications") },
                        ActionItem("Device Files", Icons.Default.Folder) { executeQuickTool("find_file") }
                    )
                )
            }
        }
    }
}

private data class ActionItem(
    val title: String,
    val icon: ImageVector,
    val onClick: () -> Unit
)

@Composable
private fun ActionCategoryCard(
    title: String,
    actions: List<ActionItem>
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkNavyCard)
            .border(1.dp, DarkNavyCardBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Text(
            text = title,
            color = NeonCyan,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        // Grid of action buttons
        val rows = actions.chunked(2)
        rows.forEach { rowActions ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                rowActions.forEach { item ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(DeepVoidBlack.copy(alpha = 0.7f))
                            .border(1.dp, DarkNavyCardBorder, RoundedCornerShape(8.dp))
                            .clickable { item.onClick() }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                            .testTag("action_btn_${item.title.lowercase().replace(" ", "_")}")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.title,
                                tint = NeonCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = item.title,
                                color = TextCyberWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
                if (rowActions.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}
