package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic JARVIS Palette
val DeepVoidBlack = Color(0xFF030712)
val DarkNavyBackground = Color(0xFF070D1F)
val DarkNavySurface = Color(0xFF0D172E)
val DarkNavyCard = Color(0xFF132244)
val DarkNavyCardBorder = Color(0xFF1E3A6E)

// Neon & Holographic Accents
val NeonCyan = Color(0xFF00F0FF)
val NeonCyanGlow = Color(0x6600F0FF)
val NeonCyanSubtle = Color(0x1A00F0FF)

val ElectricBlue = Color(0xFF0077FE)
val ArcReactorCore = Color(0xFFE0F7FF)
val ArcReactorOuter = Color(0xFF00D4FF)

val HologramGreen = Color(0xFF00FF9D)
val HologramAmber = Color(0xFFFFB800)
val HologramRed = Color(0xFFFF3366)
val HologramPurple = Color(0xFF9D4EDD)

// Text Colors
val TextCyberWhite = Color(0xFFF0F6FF)
val TextCyberDim = Color(0xFF8BA2C7)
val TextCyberMuted = Color(0xFF50688E)
