package com.example.ai

import android.content.Context
import com.example.auth.FirebaseAuthManager
import com.example.data.FirestoreSyncManager
import com.example.data.JarvisRepository
import com.example.data.model.MemoryItem
import com.example.model.ActionPlan
import com.example.model.ChatMessage
import com.example.model.JarvisState
import com.example.model.MediaAttachment
import com.example.model.MediaType
import com.example.model.MessageSender
import com.example.model.PlanStep
import com.example.model.RiskLevel
import com.example.model.StepStatus
import com.example.model.ToolResult
import com.example.tools.JarvisToolRegistry
import com.example.voice.JarvisVoiceStatus
import com.example.voice.VoiceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class JarvisBrain(
    private val context: Context,
    private val repository: JarvisRepository,
    private val scope: CoroutineScope
) {

    val toolRegistry = JarvisToolRegistry(context)
    val geminiProvider = GeminiProvider()
    val localPlanner = LocalRulePlanner()
    val mediaGenerator = MediaGenerator(context)
    val geminiMultimodalClient = GeminiMultimodalClient(context)
    val firebaseAuthManager = FirebaseAuthManager(context)
    val firestoreSyncManager = FirestoreSyncManager(context)

    // Core Intent / Tool Router
    val aiBrain = AIBrain(context, geminiProvider, localPlanner, mediaGenerator)

    private val _state = MutableStateFlow(JarvisState.IDLE)
    val state: StateFlow<JarvisState> = _state.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = MessageSender.JARVIS,
                text = "JARVIS Multimodal OS online. Standing by for voice commands, image creation, and video synthesis."
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _currentPlan = MutableStateFlow<ActionPlan?>(null)
    val currentPlan: StateFlow<ActionPlan?> = _currentPlan.asStateFlow()

    private val _pendingConfirmationPlan = MutableStateFlow<ActionPlan?>(null)
    val pendingConfirmationPlan: StateFlow<ActionPlan?> = _pendingConfirmationPlan.asStateFlow()

    var voiceManager: VoiceManager? = null
    var useCloudAi: Boolean = true

    private var activeProcessingJob: Job? = null

    init {
        // Wire stop callback when user says "stop" or "jarvis stop"
        voiceManager?.onStopRequested = {
            stopCurrentOperation()
        }

        // Listen for user name in memory
        scope.launch {
            repository.allMemory.collect { memories ->
                val name = memories.find { it.key == "user_name" || it.key == "preferred_name" }?.value
                if (!name.isNullOrBlank()) {
                    voiceManager?.userName = name
                }
            }
        }
    }

    fun getUserName(): String {
        return voiceManager?.userName ?: "Alex"
    }

    fun stopCurrentOperation() {
        activeProcessingJob?.cancel()
        voiceManager?.stopSpeaking()
        _state.value = JarvisState.IDLE
        voiceManager?.setStatus(JarvisVoiceStatus.STANDBY)
        _pendingConfirmationPlan.value = null
        val jarvisMsg = ChatMessage(
            sender = MessageSender.JARVIS,
            text = "Halted."
        )
        _messages.value = _messages.value + jarvisMsg
        voiceManager?.speak("Halted.")
    }

    fun processUserInput(input: String, attachment: MediaAttachment? = null) {
        val trimmed = input.trim()
        if (trimmed.isBlank() && attachment == null) return

        // Interruption check: "stop", "cancel", "jarvis stop", "stop listening"
        if (isStopPhrase(trimmed)) {
            stopCurrentOperation()
            return
        }

        // Cancel any active speech or ongoing task
        voiceManager?.stopSpeaking()
        activeProcessingJob?.cancel()

        // Append user chat message with optional media attachment
        val userMsg = ChatMessage(
            sender = MessageSender.USER,
            text = trimmed.ifBlank { "Analyze attached media" },
            attachment = attachment
        )
        _messages.value = _messages.value + userMsg

        _state.value = JarvisState.THINKING
        voiceManager?.setStatus(JarvisVoiceStatus.THINKING)

        activeProcessingJob = scope.launch(Dispatchers.Main) {
            try {
                val currentName = getUserName()

                // Check pending confirmation first
                val pending = _pendingConfirmationPlan.value
                if (pending != null && isAffirmative(trimmed)) {
                    _pendingConfirmationPlan.value = null
                    executePlan(pending, isConfirmed = true)
                    return@launch
                } else if (pending != null && isNegative(trimmed)) {
                    _pendingConfirmationPlan.value = null
                    _state.value = JarvisState.IDLE
                    voiceManager?.setStatus(JarvisVoiceStatus.STANDBY)
                    speakAndRecord("Action cancelled, $currentName.", false)
                    return@launch
                }

                // Core Reasoning Layer: Route intent via AIBrain
                val requestContext = RequestContext(
                    userName = currentName,
                    attachment = attachment,
                    conversationHistory = _messages.value,
                    hasPendingConfirmation = pending != null,
                    pendingPlan = pending
                )

                val decision = aiBrain.routeIntent(trimmed, requestContext)

                when (decision) {
                    is RoutedIntent.StopAction -> {
                        stopCurrentOperation()
                    }

                    is RoutedIntent.MemoryOperation -> {
                        _state.value = JarvisState.IDLE
                        voiceManager?.setStatus(JarvisVoiceStatus.STANDBY)
                        repository.saveMemory(
                            MemoryItem(
                                key = decision.key,
                                value = decision.value,
                                category = if (decision.key == "user_name") "identity" else "preference"
                            )
                        )
                        if (decision.key == "user_name") {
                            voiceManager?.userName = decision.value
                            val ack = "Understood, ${decision.value}."
                            speakAndRecord(ack, true, null)
                        } else {
                            val ack = "I've committed that to memory, $currentName."
                            speakAndRecord(ack, true, null)
                        }
                    }

                    is RoutedIntent.ImageGeneration -> {
                        _state.value = JarvisState.GENERATING_IMAGE
                        voiceManager?.setStatus(JarvisVoiceStatus.GENERATING_IMAGE)
                        voiceManager?.speak("Certainly. Creating image with Gemini 3.1 Flash Image for you now, $currentName.")

                        val generated = geminiMultimodalClient.generateOrEditImage(
                            prompt = decision.optimizedPrompt,
                            sourceImageBase64 = attachment?.base64Data,
                            aspectRatio = "1:1"
                        )

                        _state.value = JarvisState.IDLE
                        voiceManager?.setStatus(JarvisVoiceStatus.STANDBY)
                        val responseText = if (decision.isEdit) "Here is the modified image, $currentName." else "Image generated."
                        val resultMessage = ChatMessage(
                            sender = MessageSender.JARVIS,
                            text = responseText,
                            generatedMedia = generated
                        )
                        _messages.value = _messages.value + resultMessage
                        voiceManager?.speak(responseText)
                    }

                    is RoutedIntent.VideoGeneration -> {
                        _state.value = JarvisState.GENERATING_VIDEO
                        voiceManager?.setStatus(JarvisVoiceStatus.GENERATING_VIDEO)
                        voiceManager?.speak("Generating cinematic video sequence via Veo 3 for you now, $currentName.")

                        val (videoMedia, storyboard) = geminiMultimodalClient.generateVideoWithVeo(
                            prompt = decision.optimizedPrompt,
                            sourceImageBase64 = attachment?.base64Data,
                            aspectRatio = "16:9"
                        )

                        _state.value = JarvisState.IDLE
                        voiceManager?.setStatus(JarvisVoiceStatus.STANDBY)
                        val responseText = "Veo cinematic video generation complete, $currentName."
                        val resultMessage = ChatMessage(
                            sender = MessageSender.JARVIS,
                            text = responseText,
                            generatedMedia = videoMedia,
                            videoStoryboard = storyboard
                        )
                        _messages.value = _messages.value + resultMessage
                        voiceManager?.speak(responseText)
                    }

                    is RoutedIntent.MusicGeneration -> {
                        _state.value = JarvisState.GENERATING
                        voiceManager?.setStatus(JarvisVoiceStatus.GENERATING)
                        voiceManager?.speak("Composing soundtrack with Lyria 3 for you now, $currentName.")

                        val musicMedia = geminiMultimodalClient.generateMusic(
                            prompt = decision.optimizedPrompt,
                            isProFullTrack = decision.isProTrack
                        )

                        _state.value = JarvisState.IDLE
                        voiceManager?.setStatus(JarvisVoiceStatus.STANDBY)
                        val responseText = "Lyria music composition complete. Audio track synthesized, $currentName."
                        val resultMessage = ChatMessage(
                            sender = MessageSender.JARVIS,
                            text = responseText,
                            generatedMedia = musicMedia
                        )
                        _messages.value = _messages.value + resultMessage
                        voiceManager?.speak(responseText)
                    }

                    is RoutedIntent.LiveVoiceConversation -> {
                        _state.value = JarvisState.THINKING
                        voiceManager?.setStatus(JarvisVoiceStatus.THINKING)
                        val grounded = geminiMultimodalClient.sendChat(
                            userInput = decision.prompt,
                            history = _messages.value,
                            modelChoice = GeminiModelChoice.LIVE_CONVERSATION
                        )
                        _state.value = JarvisState.IDLE
                        voiceManager?.setStatus(JarvisVoiceStatus.STANDBY)
                        speakAndRecord(grounded.replyText, true, null)
                    }

                    is RoutedIntent.WebSearch -> {
                        val plan = ActionPlan(
                            userIntent = trimmed,
                            speechResponse = if (decision.targetApp != null) "Opening ${decision.targetApp} and searching for ${decision.query}, $currentName." else "Searching the web for ${decision.query}, $currentName.",
                            riskLevel = RiskLevel.LOW,
                            steps = if (decision.targetApp != null) {
                                listOf(
                                    PlanStep("1", "Open ${decision.targetApp}", "open_app", mapOf("app" to decision.targetApp)),
                                    PlanStep("2", "Search for '${decision.query}'", "search_web", mapOf("query" to decision.query))
                                )
                            } else {
                                listOf(
                                    PlanStep("1", "Search for '${decision.query}'", "search_web", mapOf("query" to decision.query))
                                )
                            }
                        )
                        executePlan(plan, isConfirmed = false)
                    }

                    is RoutedIntent.DeviceAction -> {
                        val toolName = when (decision.category) {
                            DeviceActionCategory.LAUNCH_APP -> "open_app"
                            DeviceActionCategory.SET_ALARM -> "set_alarm"
                            DeviceActionCategory.SEND_COMMUNICATION -> "send_email"
                            DeviceActionCategory.ACCESSIBILITY_INTERACTION -> {
                                if (decision.parameters.containsKey("direction")) "scroll" else "tap_element"
                            }
                            else -> "system_setting"
                        }

                        val plan = ActionPlan(
                            userIntent = trimmed,
                            speechResponse = decision.description.ifBlank { "Executing request on your device, $currentName." },
                            riskLevel = decision.riskLevel,
                            requiresConfirmation = decision.requiresConfirmation,
                            steps = listOf(
                                PlanStep("1", decision.target, toolName, decision.parameters)
                            )
                        )

                        if (plan.requiresConfirmation || plan.riskLevel == RiskLevel.HIGH) {
                            _pendingConfirmationPlan.value = plan
                            _state.value = JarvisState.IDLE
                            voiceManager?.setStatus(JarvisVoiceStatus.STANDBY)
                            speakAndRecord(plan.speechResponse, true, plan)
                        } else {
                            executePlan(plan, isConfirmed = false)
                        }
                    }

                    is RoutedIntent.Conversational -> {
                        _currentPlan.value = null
                        _state.value = JarvisState.IDLE
                        voiceManager?.setStatus(JarvisVoiceStatus.STANDBY)
                        speakAndRecord(decision.speechResponse, true, null)
                    }
                }
            } catch (e: Exception) {
                _state.value = JarvisState.ERROR
                voiceManager?.setStatus(JarvisVoiceStatus.ERROR)
                val errText = "I encountered an issue processing that: ${e.message}"
                speakAndRecord(errText, false)
            }
        }
    }

    fun confirmPendingPlan() {
        val pending = _pendingConfirmationPlan.value ?: return
        _pendingConfirmationPlan.value = null
        executePlan(pending, isConfirmed = true)
    }

    fun cancelPendingPlan() {
        _pendingConfirmationPlan.value = null
        _state.value = JarvisState.IDLE
        voiceManager?.setStatus(JarvisVoiceStatus.STANDBY)
        speakAndRecord("Action cancelled.", false)
    }

    fun clearConversation() {
        activeProcessingJob?.cancel()
        voiceManager?.stopSpeaking()
        val name = getUserName()
        _messages.value = listOf(
            ChatMessage(
                sender = MessageSender.JARVIS,
                text = "Memory buffer cleared. Multimodal sensors ready, $name."
            )
        )
        _currentPlan.value = null
        _pendingConfirmationPlan.value = null
        _state.value = JarvisState.IDLE
        voiceManager?.setStatus(JarvisVoiceStatus.STANDBY)
    }

    private fun executePlan(plan: ActionPlan, isConfirmed: Boolean) {
        activeProcessingJob = scope.launch(Dispatchers.Main) {
            _state.value = JarvisState.EXECUTING

            if (!isConfirmed && plan.speechResponse.isNotBlank()) {
                voiceManager?.speak(plan.speechResponse)
            }

            val updatedSteps = plan.steps.map { it.copy() }
            var allSuccess = true
            val executedTools = mutableListOf<String>()

            for (step in updatedSteps) {
                step.status = StepStatus.RUNNING
                _currentPlan.value = plan.copy(steps = updatedSteps)

                delay(250)

                val result: ToolResult = toolRegistry.execute(step)
                executedTools.add("${step.toolName}:${result.success}")

                if (result.success) {
                    step.status = StepStatus.SUCCESS
                    step.resultDetail = result.result
                } else {
                    step.status = StepStatus.FAILED
                    step.resultDetail = result.limitationNote ?: result.result
                    allSuccess = false
                }
                _currentPlan.value = plan.copy(steps = updatedSteps)
            }

            _state.value = JarvisState.IDLE
            voiceManager?.setStatus(JarvisVoiceStatus.STANDBY)

            val name = getUserName()
            val finalSpoken = when {
                allSuccess && isConfirmed -> "Action confirmed and executed successfully, $name."
                allSuccess -> "Task completed."
                else -> {
                    val firstFailure = updatedSteps.find { it.status == StepStatus.FAILED }
                    firstFailure?.resultDetail ?: "I could not complete all steps of this request."
                }
            }

            speakAndRecord(finalSpoken, allSuccess, plan.copy(steps = updatedSteps))

            repository.logCommand(
                query = plan.userIntent,
                response = finalSpoken,
                success = allSuccess,
                tools = executedTools.joinToString(", ")
            )
        }
    }

    private fun speakAndRecord(spokenText: String, success: Boolean, plan: ActionPlan? = null) {
        voiceManager?.speak(spokenText)
        val jarvisMsg = ChatMessage(
            sender = MessageSender.JARVIS,
            text = spokenText,
            plan = plan
        )
        _messages.value = _messages.value + jarvisMsg
    }

    private fun isStopPhrase(text: String): Boolean {
        val lower = text.lowercase().trim()
        val stops = listOf("stop", "cancel", "jarvis stop", "stop listening", "quiet", "pause", "halt", "nevermind", "never mind")
        return stops.any { lower == it || lower.startsWith("jarvis stop") }
    }

    private fun isAffirmative(text: String): Boolean {
        val lower = text.trim().lowercase()
        return lower in listOf("yes", "yeah", "yep", "proceed", "confirm", "send", "send it", "do it", "sure", "ok", "okay")
    }

    private fun isNegative(text: String): Boolean {
        val lower = text.trim().lowercase()
        return lower in listOf("no", "cancel", "stop", "abort", "don't", "never mind")
    }
}
