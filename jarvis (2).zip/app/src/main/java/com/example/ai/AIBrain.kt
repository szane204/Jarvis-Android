package com.example.ai

import android.content.Context
import com.example.data.JarvisRepository
import com.example.data.model.MemoryItem
import com.example.model.ActionPlan
import com.example.model.ChatMessage
import com.example.model.MediaAttachment
import com.example.model.MediaType
import com.example.model.PlanStep
import com.example.model.RiskLevel
import com.example.tools.JarvisToolRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.regex.Pattern

/**
 * Categorization of device actions routed by the AI Brain.
 */
enum class DeviceActionCategory {
    LAUNCH_APP,
    SYSTEM_SETTING,
    SET_ALARM,
    SEND_COMMUNICATION,
    ACCESSIBILITY_INTERACTION,
    MEDIA_CONTROL
}

/**
 * Strongly typed decision model emitted by the AIBrain Intent / Tool Router.
 */
sealed class RoutedIntent {
    data class WebSearch(
        val query: String,
        val targetApp: String? = null,
        val suggestedSearchUrl: String? = null
    ) : RoutedIntent()

    data class ImageGeneration(
        val rawPrompt: String,
        val optimizedPrompt: String,
        val isEdit: Boolean = false,
        val sourceAttachment: MediaAttachment? = null
    ) : RoutedIntent()

    data class VideoGeneration(
        val rawPrompt: String,
        val optimizedPrompt: String,
        val durationSeconds: Int = 10,
        val isChainedFromImage: Boolean = false,
        val sourceImageUrl: String? = null
    ) : RoutedIntent()

    data class DeviceAction(
        val category: DeviceActionCategory,
        val target: String,
        val parameters: Map<String, String>,
        val requiresConfirmation: Boolean = false,
        val riskLevel: RiskLevel = RiskLevel.LOW,
        val description: String = ""
    ) : RoutedIntent()

    data class MemoryOperation(
        val operation: String, // "STORE", "RECALL", "CLEAR"
        val key: String,
        val value: String
    ) : RoutedIntent()

    data class Conversational(
        val speechResponse: String,
        val fullDetailText: String = speechResponse
    ) : RoutedIntent()

    data class MusicGeneration(
        val rawPrompt: String,
        val optimizedPrompt: String,
        val isProTrack: Boolean = false
    ) : RoutedIntent()

    data class LiveVoiceConversation(
        val prompt: String
    ) : RoutedIntent()

    object StopAction : RoutedIntent()
}

/**
 * Contextual state passed into the AIBrain during evaluation.
 */
data class RequestContext(
    val userName: String = "Alex",
    val attachment: MediaAttachment? = null,
    val conversationHistory: List<ChatMessage> = emptyList(),
    val hasPendingConfirmation: Boolean = false,
    val pendingPlan: ActionPlan? = null
)

/**
 * Central reasoning layer that parses speech-to-text input and routes intent
 * between Web Search, Image Generation, Video Generation, Device Actions, and Memory.
 */
class AIBrain(
    private val context: Context,
    private val geminiProvider: GeminiProvider = GeminiProvider(),
    private val localPlanner: LocalRulePlanner = LocalRulePlanner(),
    private val mediaGenerator: MediaGenerator = MediaGenerator(context)
) {

    /**
     * Evaluates text from Speech-to-Text alongside request context, returning the resolved intent.
     */
    suspend fun routeIntent(
        userInput: String,
        requestContext: RequestContext
    ): RoutedIntent = withContext(Dispatchers.Default) {
        val trimmed = userInput.trim()
        val lower = trimmed.lowercase(Locale.ROOT)
            .removePrefix("hey jarvis, ")
            .removePrefix("hey jarvis ")
            .removePrefix("jarvis, ")
            .removePrefix("jarvis ")
            .trim()

        // 1. Immediate Interruption / Stop
        if (isStopCommand(lower)) {
            return@withContext RoutedIntent.StopAction
        }

        // 2. User Name Declaration: "My name is [Name]" or "Remember that my name is [Name]"
        if (isNameDeclaration(lower)) {
            val name = extractName(trimmed)
            if (name.isNotBlank()) {
                return@withContext RoutedIntent.MemoryOperation(
                    operation = "STORE",
                    key = "user_name",
                    value = name
                )
            }
        }

        // 3. User Identity Recall: "What is my name?" or "Do you know who I am?"
        if (lower.contains("what is my name") || lower.contains("who am i") || lower.contains("what's my name")) {
            val currentName = requestContext.userName
            return@withContext RoutedIntent.Conversational(
                speechResponse = "Your name is $currentName, as recorded in my system memory.",
                fullDetailText = "Identity confirmed: $currentName"
            )
        }

        // 4. General Capability Inquiry: "What can you do?"
        if (lower.contains("what can you do") || lower.contains("what are your capabilities")) {
            val currentName = requestContext.userName
            val response = "Quite a lot, $currentName. I can answer questions, create images and videos, analyze files, write code, search for information, and help you control supported functions on your device."
            return@withContext RoutedIntent.Conversational(speechResponse = response)
        }

        // 5. Memory Storage Request: "Remember that [preference]"
        if (lower.startsWith("remember that ") || lower.startsWith("remember ")) {
            val fact = trimmed.removePrefix("remember that ").removePrefix("remember ").trim()
            return@withContext RoutedIntent.MemoryOperation(
                operation = "STORE",
                key = "preference_${System.currentTimeMillis() % 10000}",
                value = fact
            )
        }

        // 6. Image Generation Intent: "Make me an image...", "Create a picture of...", "Draw a..."
        if (isImageGenerationIntent(lower)) {
            val rawPrompt = extractImagePrompt(trimmed)
            val optimizedPrompt = "Masterpiece digital artwork of $rawPrompt, dense futuristic skyscrapers, flying vehicles, cinematic nighttime lighting, neon reflections, wide cinematic shot, photorealistic futuristic science-fiction concept art, octane render 8k"
            return@withContext RoutedIntent.ImageGeneration(
                rawPrompt = rawPrompt,
                optimizedPrompt = optimizedPrompt,
                isEdit = requestContext.attachment != null,
                sourceAttachment = requestContext.attachment
            )
        }

        // 7. Video Generation Intent: "Make a video...", "Turn this into a cinematic video..."
        if (isVideoGenerationIntent(lower)) {
            // Check if user is chaining from a previously generated image
            val lastImage = requestContext.conversationHistory.lastOrNull { it.generatedMedia?.type == MediaType.IMAGE }
            val isChained = lastImage != null && (lower.contains("her") || lower.contains("it") || lower.contains("this image") || lower.contains("turn"))
            val effectivePrompt = if (isChained) {
                "${lastImage?.generatedMedia?.prompt ?: ""}. $trimmed"
            } else {
                trimmed
            }

            return@withContext RoutedIntent.VideoGeneration(
                rawPrompt = trimmed,
                optimizedPrompt = effectivePrompt,
                durationSeconds = 10,
                isChainedFromImage = isChained,
                sourceImageUrl = lastImage?.generatedMedia?.urlOrPath
            )
        }

        // 7b. Music Generation Intent: "Generate music...", "Create a track...", "Make a song..."
        if (isMusicGenerationIntent(lower)) {
            val musicPrompt = extractMusicPrompt(trimmed)
            return@withContext RoutedIntent.MusicGeneration(
                rawPrompt = musicPrompt,
                optimizedPrompt = "Cinematic high-fidelity electronic orchestral score with pulsing bass and melodic synthesizer arpeggios, $musicPrompt",
                isProTrack = lower.contains("full track") || lower.contains("song")
            )
        }

        // 8. Device Actions: Launching Apps, Alarms, System Settings, Accessibility Gestures
        val deviceAction = parseDeviceAction(lower, trimmed)
        if (deviceAction != null) {
            return@withContext deviceAction
        }

        // 9. Web Search Intent: "Search for...", "Google...", "Look up..."
        val searchIntent = parseWebSearchIntent(lower, trimmed)
        if (searchIntent != null) {
            return@withContext searchIntent
        }

        // 10. Fallback to Multimodal LLM Reasoning via Gemini Provider
        return@withContext try {
            val analysis = geminiProvider.planTaskWithHistoryAndAttachment(
                userInput = trimmed,
                attachment = requestContext.attachment,
                history = requestContext.conversationHistory,
                userMemoryContext = "User name is ${requestContext.userName}"
            )

            when (analysis.mediaIntent) {
                "IMAGE" -> RoutedIntent.ImageGeneration(
                    rawPrompt = analysis.mediaPrompt.ifBlank { trimmed },
                    optimizedPrompt = analysis.mediaPrompt.ifBlank { trimmed },
                    isEdit = requestContext.attachment != null,
                    sourceAttachment = requestContext.attachment
                )
                "VIDEO" -> RoutedIntent.VideoGeneration(
                    rawPrompt = analysis.mediaPrompt.ifBlank { trimmed },
                    optimizedPrompt = analysis.mediaPrompt.ifBlank { trimmed }
                )
                else -> {
                    if (analysis.plan.steps.isNotEmpty()) {
                        val firstStep = analysis.plan.steps.first()
                        RoutedIntent.DeviceAction(
                            category = mapToolNameToCategory(firstStep.toolName),
                            target = firstStep.title,
                            parameters = firstStep.params,
                            requiresConfirmation = analysis.plan.requiresConfirmation,
                            riskLevel = analysis.plan.riskLevel,
                            description = analysis.plan.speechResponse
                        )
                    } else {
                        RoutedIntent.Conversational(
                            speechResponse = analysis.plan.speechResponse.ifBlank { "Acknowledged, ${requestContext.userName}." }
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // Local fallback rule planner
            val localPlan = localPlanner.planFromUserInput(trimmed)
            if (localPlan.steps.isNotEmpty()) {
                val step = localPlan.steps.first()
                RoutedIntent.DeviceAction(
                    category = mapToolNameToCategory(step.toolName),
                    target = step.title,
                    parameters = step.params,
                    requiresConfirmation = localPlan.requiresConfirmation,
                    riskLevel = localPlan.riskLevel,
                    description = localPlan.speechResponse
                )
            } else {
                RoutedIntent.Conversational(speechResponse = localPlan.speechResponse)
            }
        }
    }

    private fun isStopCommand(lower: String): Boolean {
        val stops = listOf("stop", "cancel", "jarvis stop", "stop listening", "quiet", "pause", "halt", "nevermind", "never mind")
        return stops.any { lower == it || lower.startsWith("jarvis stop") }
    }

    private fun isNameDeclaration(lower: String): Boolean {
        return lower.startsWith("my name is ") ||
                lower.startsWith("call me ") ||
                lower.startsWith("remember that my name is ")
    }

    private fun extractName(text: String): String {
        val clean = text.trim()
        val match = Regex("(?i)(?:my name is|call me|remember that my name is)\\s+([a-zA-Z]+)").find(clean)
        return match?.groupValues?.get(1)?.replaceFirstChar { it.uppercase() } ?: ""
    }

    private fun isImageGenerationIntent(lower: String): Boolean {
        return lower.startsWith("generate image") ||
                lower.startsWith("generate an image") ||
                lower.startsWith("create an image") ||
                lower.startsWith("make an image") ||
                lower.startsWith("make me an image") ||
                lower.startsWith("draw ") ||
                lower.contains("make a picture of") ||
                lower.contains("paint a") ||
                lower.contains("create an image of")
    }

    private fun extractImagePrompt(text: String): String {
        return text.replace(Regex("(?i)^(generate|create|draw|make|paint)\\s+(an?\\s+)?(image|picture|photo|illustration)?\\s*(of)?"), "").trim()
    }

    private fun isVideoGenerationIntent(lower: String): Boolean {
        return lower.startsWith("generate video") ||
                lower.startsWith("create video") ||
                lower.startsWith("make a video") ||
                lower.startsWith("make video") ||
                lower.startsWith("make me a video") ||
                lower.contains("cinematic video") ||
                lower.contains("create a video from") ||
                lower.contains("turn this into a video") ||
                lower.contains("turn her into a") ||
                lower.contains("turn him into a")
    }

    private fun isMusicGenerationIntent(lower: String): Boolean {
        return lower.startsWith("generate music") ||
                lower.startsWith("create music") ||
                lower.startsWith("make music") ||
                lower.startsWith("compose ") ||
                lower.startsWith("make a song") ||
                lower.startsWith("create a song") ||
                lower.startsWith("generate a soundtrack") ||
                lower.startsWith("make a track") ||
                lower.contains("generate music for") ||
                lower.contains("music clip")
    }

    private fun extractMusicPrompt(text: String): String {
        return text.replace(Regex("(?i)^(generate|create|make|compose)\\s+(a\\s+)?(music|song|track|soundtrack|clip)?\\s*(of|for|about)?"), "").trim()
    }

    private fun parseDeviceAction(lower: String, original: String): RoutedIntent.DeviceAction? {
        // App Launch Intent: "open [App]" / "launch [App]"
        if (lower.startsWith("open ") || lower.startsWith("launch ")) {
            val match = Regex("(?i)(?:open|launch)\\s+([a-zA-Z0-9_ -]+)").find(original)
            val appName = match?.groupValues?.get(1)?.trim()?.split(" ")?.firstOrNull()
                ?: lower.removePrefix("open ").removePrefix("launch ").trim().replaceFirstChar { it.uppercase() }
            // Avoid capturing commands like "open camera and search" here
            if (!lower.contains("and search")) {
                return RoutedIntent.DeviceAction(
                    category = DeviceActionCategory.LAUNCH_APP,
                    target = appName,
                    parameters = mapOf("app" to appName),
                    description = "Opening $appName, Sir."
                )
            }
        }

        // Alarm Intent: "set an alarm for [time]"
        if (lower.contains("set an alarm") || lower.contains("set alarm")) {
            val timeRegex = Pattern.compile("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?", Pattern.CASE_INSENSITIVE)
            val matcher = timeRegex.matcher(lower)
            if (matcher.find()) {
                val hour = matcher.group(1) ?: "7"
                val min = matcher.group(2) ?: "0"
                return RoutedIntent.DeviceAction(
                    category = DeviceActionCategory.SET_ALARM,
                    target = "Alarm",
                    parameters = mapOf("hour" to hour, "minute" to min),
                    description = "Setting an alarm for $hour:$min."
                )
            }
        }

        // Communication Intent: "send an email to [name] saying [message]"
        if (lower.startsWith("send an email to") || lower.startsWith("send email to")) {
            val recipient = original.substringAfter("to ").substringBefore(" saying").trim()
            val message = original.substringAfter("saying ", "").trim()
            return RoutedIntent.DeviceAction(
                category = DeviceActionCategory.SEND_COMMUNICATION,
                target = recipient,
                parameters = mapOf("recipient" to recipient, "message" to message),
                requiresConfirmation = true,
                riskLevel = RiskLevel.MEDIUM,
                description = "I have drafted the email to $recipient. Would you like me to send it?"
            )
        }

        // Accessibility gestures: "tap [button]" / "scroll [direction]"
        if (lower.startsWith("tap ") || lower.startsWith("click ")) {
            val targetElement = original.substringAfter(" ").trim()
            return RoutedIntent.DeviceAction(
                category = DeviceActionCategory.ACCESSIBILITY_INTERACTION,
                target = targetElement,
                parameters = mapOf("target" to targetElement),
                description = "Tapping $targetElement via Accessibility Service."
            )
        }

        if (lower.startsWith("scroll down") || lower.startsWith("scroll up")) {
            val dir = if (lower.contains("up")) "up" else "down"
            return RoutedIntent.DeviceAction(
                category = DeviceActionCategory.ACCESSIBILITY_INTERACTION,
                target = "Screen",
                parameters = mapOf("direction" to dir),
                description = "Scrolling $dir."
            )
        }

        return null
    }

    private fun parseWebSearchIntent(lower: String, original: String): RoutedIntent.WebSearch? {
        if (lower.startsWith("search for ") || lower.startsWith("search ")) {
            val query = original.removePrefix("search for ").removePrefix("search ").trim()
            return RoutedIntent.WebSearch(query = query)
        }

        if (lower.startsWith("google ") || lower.startsWith("look up ")) {
            val query = original.removePrefix("google ").removePrefix("look up ").trim()
            return RoutedIntent.WebSearch(query = query)
        }

        // Chained command: "open youtube and search [query]"
        if (lower.contains("and search ")) {
            val app = original.substringBefore(" and search").substringAfter("open ").trim()
            val query = original.substringAfter("and search ").trim()
            return RoutedIntent.WebSearch(query = query, targetApp = app)
        }

        return null
    }

    private fun mapToolNameToCategory(toolName: String): DeviceActionCategory {
        return when (toolName) {
            "open_app" -> DeviceActionCategory.LAUNCH_APP
            "set_alarm" -> DeviceActionCategory.SET_ALARM
            "send_email", "send_sms" -> DeviceActionCategory.SEND_COMMUNICATION
            "tap_element", "scroll", "press_back", "press_home" -> DeviceActionCategory.ACCESSIBILITY_INTERACTION
            else -> DeviceActionCategory.SYSTEM_SETTING
        }
    }
}
