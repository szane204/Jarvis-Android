package com.example.ai

import com.example.model.ActionPlan
import com.example.model.PlanStep
import com.example.model.RiskLevel
import java.util.Locale
import java.util.regex.Pattern

class LocalRulePlanner {

    fun planFromUserInput(input: String): ActionPlan {
        val cleanInput = input.trim()
        val lower = cleanInput.lowercase(Locale.ROOT)
            .removePrefix("hey jarvis, ")
            .removePrefix("hey jarvis ")
            .removePrefix("jarvis, ")
            .removePrefix("jarvis ")
            .trim()

        // 1. Chained command: "open youtube and search [query]"
        val openAndSearchPattern = Pattern.compile("open (\\w+) and search (.+)", Pattern.CASE_INSENSITIVE)
        val mSearch = openAndSearchPattern.matcher(lower)
        if (mSearch.matches()) {
            val appRaw = mSearch.group(1) ?: "YouTube"
            val queryRaw = mSearch.group(2) ?: ""
            val app = extractOriginalToken(cleanInput, appRaw)
            val query = extractOriginalToken(cleanInput, queryRaw)
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Opening $app and searching for $query, Sir.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Launch $app", "open_app", mapOf("app" to app)),
                    PlanStep("2", "Search for '$query'", "search_web", mapOf("query" to query))
                )
            )
        }

        // 2. "search [app] for [query]", e.g. "search youtube for gta 6"
        val searchInAppPattern = Pattern.compile("search (\\w+) for (.+)", Pattern.CASE_INSENSITIVE)
        val mSearchInApp = searchInAppPattern.matcher(lower)
        if (mSearchInApp.matches()) {
            val appRaw = mSearchInApp.group(1) ?: "YouTube"
            val queryRaw = mSearchInApp.group(2) ?: ""
            val app = extractOriginalToken(cleanInput, appRaw)
            val query = extractOriginalToken(cleanInput, queryRaw)
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Opening $app and searching for $query, Sir.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Launch $app", "open_app", mapOf("app" to app)),
                    PlanStep("2", "Search for '$query'", "search_web", mapOf("query" to query))
                )
            )
        }

        // 3. Multi-step: "Find the latest photo ... and email to ..."
        if ((lower.contains("photo") || lower.contains("screenshot") || lower.contains("file")) &&
            (lower.contains("email") || lower.contains("send to"))
        ) {
            val recipientRaw = extractRecipient(lower) ?: "recipient"
            val recipient = extractOriginalToken(cleanInput, recipientRaw)
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "I've prepared the email with the requested attachment for $recipient. Shall I proceed?",
                riskLevel = RiskLevel.MEDIUM,
                requiresConfirmation = true,
                confirmationTitle = "Send Email Attachment",
                confirmationDetails = mapOf(
                    "Recipient" to recipient,
                    "Action" to "Attach recent media and draft email",
                    "Security Level" to "Requires confirmation before transmission"
                ),
                steps = listOf(
                    PlanStep("1", "Locate device media", "find_file"),
                    PlanStep("2", "Prepare Email to $recipient", "draft_email", mapOf("recipient" to recipient, "subject" to "Shared File", "body" to "Attached file requested via JARVIS."))
                )
            )
        }

        // 4. Email: "send an email to [name] saying [message]"
        val emailPattern = Pattern.compile("(?:send|draft) (?:an )?email to ([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}|\\w+)(?:\\s+(?:saying|with message|telling (?:him|her|them) that)\\s+(.+))?", Pattern.CASE_INSENSITIVE)
        val mEmail = emailPattern.matcher(lower)
        if (mEmail.matches() || lower.startsWith("email ")) {
            val recipientRaw = mEmail.group(1) ?: extractRecipient(lower) ?: "David"
            val recipient = extractOriginalToken(cleanInput, recipientRaw)
            val body = mEmail.group(2) ?: cleanInput.substringAfter("saying", "Message sent via JARVIS")
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "I've prepared the email to $recipient. Shall I send it?",
                riskLevel = RiskLevel.MEDIUM,
                requiresConfirmation = true,
                confirmationTitle = "Send Email",
                confirmationDetails = mapOf(
                    "To" to recipient,
                    "Message" to body.trim()
                ),
                steps = listOf(
                    PlanStep(
                        id = "1",
                        title = "Draft email to $recipient",
                        toolName = "draft_email",
                        params = mapOf("recipient" to recipient, "body" to body.trim(), "subject" to "Update from JARVIS")
                    )
                )
            )
        }

        // 5. WhatsApp: "open whatsapp and message [name] that [message]" or "whatsapp [name]: [message]"
        if (lower.contains("whatsapp") || lower.startsWith("message ") || lower.startsWith("text ")) {
            val nameRaw = extractRecipient(lower) ?: "Contact"
            val name = extractOriginalToken(cleanInput, nameRaw)
            val message = when {
                lower.contains("saying ") -> lower.substringAfter("saying ").trim()
                lower.contains("that ") -> lower.substringAfter("that ").trim()
                lower.contains(":") -> lower.substringAfter(":").trim()
                else -> "I'm outside."
            }
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Preparing WhatsApp message for $name.",
                riskLevel = RiskLevel.MEDIUM,
                requiresConfirmation = true,
                confirmationTitle = "Send WhatsApp Message",
                confirmationDetails = mapOf("Recipient" to name, "Message" to message),
                steps = listOf(
                    PlanStep("1", "Open WhatsApp conversation with $name", "send_whatsapp", mapOf("phone" to name, "message" to message))
                )
            )
        }

        // 6. Open app: "open instagram", "launch spotify", "open chrome"
        if (lower.startsWith("open ") || lower.startsWith("launch ")) {
            val appRaw = lower.removePrefix("open ").removePrefix("launch ").trim()
            val app = extractOriginalToken(cleanInput, appRaw)
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Opening $app.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Open $app", "open_app", mapOf("app" to app))
                )
            )
        }

        // 7. Web Search: "search for [query]", "search [query]"
        if (lower.startsWith("search ") || lower.contains("search for")) {
            val queryRaw = if (lower.contains(" for ")) lower.substringAfter(" for ").trim() else lower.removePrefix("search ").trim()
            val query = extractOriginalToken(cleanInput, queryRaw)
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Searching the web for $query.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Search web for '$query'", "search_web", mapOf("query" to query))
                )
            )
        }

        // 8. Alarms: "set an alarm for 7 AM", "alarm for 7:30"
        if (lower.contains("alarm")) {
            val (hour, minute) = parseTime(lower)
            val timeStr = String.format("%02d:%02d", hour, minute)
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Alarm set for $timeStr, Sir.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Set alarm for $timeStr", "set_alarm", mapOf("hour" to hour.toString(), "minute" to minute.toString()))
                )
            )
        }

        // 9. Timers: "set a timer for 10 minutes"
        if (lower.contains("timer")) {
            val minutes = Regex("(\\d+)\\s*(?:min|minute)").find(lower)?.groupValues?.get(1)?.toIntOrNull() ?: 10
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Timer set for $minutes minutes.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Start $minutes-minute timer", "set_timer", mapOf("minutes" to minutes.toString()))
                )
            )
        }

        // 10. Notifications: "read my notifications", "summarize notifications"
        if (lower.contains("notification")) {
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Accessing notifications.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Fetch and summarize active notifications", "read_notifications")
                )
            )
        }

        // 11. Wi-Fi / Bluetooth
        if (lower.contains("wi-fi") || lower.contains("wifi")) {
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Opening Wi-Fi controls.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Open Wi-Fi panel", "toggle_wifi")
                )
            )
        }
        if (lower.contains("bluetooth")) {
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Opening Bluetooth settings.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Open Bluetooth settings", "toggle_bluetooth")
                )
            )
        }

        // 12. Screenshots: "take a screenshot"
        if (lower.contains("screenshot")) {
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Taking screenshot.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Capture screen", "take_screenshot")
                )
            )
        }

        // 13. Navigation: "go back", "go home", "recent apps"
        if (lower == "go back" || lower == "back") {
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Navigating back.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(PlanStep("1", "Go back", "press_back"))
            )
        }
        if (lower == "go home" || lower == "home") {
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Navigating home.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(PlanStep("1", "Return to Home", "go_home"))
            )
        }
        if (lower.contains("recent apps") || lower.contains("recents")) {
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Opening recent applications.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(PlanStep("1", "Show recent apps", "recent_apps"))
            )
        }

        // 14. UI Tapping: "tap the button that says Continue", "tap continue"
        if (lower.startsWith("tap ") || lower.startsWith("click ")) {
            val targetRaw = lower.removePrefix("tap the button that says ")
                .removePrefix("tap the button ")
                .removePrefix("tap ")
                .removePrefix("click ")
                .trim('\"', '\'', ' ')
            val target = extractOriginalToken(cleanInput, targetRaw)
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Tapping $target.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Tap '$target'", "tap_element", mapOf("target" to target))
                )
            )
        }

        // 15. Scroll: "scroll down", "scroll up"
        if (lower.contains("scroll down") || lower.contains("scroll up")) {
            val direction = if (lower.contains("up")) "up" else "down"
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Scrolling $direction.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Scroll $direction", "scroll", mapOf("direction" to direction))
                )
            )
        }

        // 16. Calendar: "what's on my calendar today", "create calendar event"
        if (lower.contains("calendar")) {
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Opening your calendar.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Open Calendar", "create_calendar_event", mapOf("title" to "Meeting"))
                )
            )
        }

        // 17. Volume control
        if (lower.contains("volume")) {
            val dir = if (lower.contains("down") || lower.contains("decrease") || lower.contains("lower")) "down" else "up"
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Adjusting volume.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Adjust volume $dir", "adjust_volume", mapOf("direction" to dir))
                )
            )
        }

        // 18. Settings: "open settings"
        if (lower.contains("settings")) {
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Opening System Settings.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Open Settings", "open_settings")
                )
            )
        }

        // 19. Routines: "good morning"
        if (lower.contains("good morning")) {
            return ActionPlan(
                userIntent = cleanInput,
                speechResponse = "Good morning, Sir. Checking notifications and preparing your schedule.",
                riskLevel = RiskLevel.LOW,
                steps = listOf(
                    PlanStep("1", "Check notifications", "read_notifications"),
                    PlanStep("2", "Open calendar", "create_calendar_event", mapOf("title" to "Today's Agenda"))
                )
            )
        }

        // Default conversational response / web search fallback
        return ActionPlan(
            userIntent = cleanInput,
            speechResponse = "Searching the web for information regarding '$cleanInput', Sir.",
            riskLevel = RiskLevel.LOW,
            steps = listOf(
                PlanStep("1", "Search web for '$cleanInput'", "search_web", mapOf("query" to cleanInput))
            )
        )
    }

    private fun extractOriginalToken(full: String, token: String): String {
        val trimmedToken = token.trim('\"', '\'', ' ')
        if (trimmedToken.isEmpty()) return ""
        val idx = full.indexOf(trimmedToken, ignoreCase = true)
        if (idx != -1) {
            return full.substring(idx, idx + trimmedToken.length).trim()
        }
        return trimmedToken.replaceFirstChar { it.uppercase() }
    }

    private fun extractRecipient(text: String): String? {
        val words = text.split(" ")
        val toIndex = words.indexOf("to")
        if (toIndex != -1 && toIndex + 1 < words.size) {
            return words[toIndex + 1].trim(',', '.', ':')
        }
        val andMessageIndex = words.indexOf("message")
        if (andMessageIndex != -1 && andMessageIndex + 1 < words.size) {
            return words[andMessageIndex + 1].trim(',', '.', ':')
        }
        return null
    }

    private fun parseTime(text: String): Pair<Int, Int> {
        val timeRegex = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?")
        val match = timeRegex.find(text)
        if (match != null) {
            var hour = match.groupValues[1].toIntOrNull() ?: 7
            val min = match.groupValues[2].toIntOrNull() ?: 0
            val ampm = match.groupValues[3].lowercase()
            if (ampm == "pm" && hour < 12) hour += 12
            if (ampm == "am" && hour == 12) hour = 0
            return Pair(hour, min)
        }
        return Pair(7, 0)
    }
}
