package com.example.ai

import com.example.model.ActionPlan

interface AiProvider {
    suspend fun planTask(userInput: String, userMemoryContext: String = ""): ActionPlan
}
