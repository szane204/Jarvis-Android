package com.example.ai

import com.example.BuildConfig
import com.example.model.ActionPlan
import com.example.model.ChatMessage
import com.example.model.MediaAttachment
import com.example.model.MessageSender
import com.example.model.PlanStep
import com.example.model.RiskLevel
import com.example.util.SpeechSanitizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class GeminiAnalysisResult(
    val plan: ActionPlan,
    val mediaIntent: String = "NONE", // "IMAGE", "VIDEO", "NONE"
    val mediaPrompt: String = "",
    val fullResponseText: String = ""
)

class GeminiProvider(
    private var customApiKey: String? = null
) : AiProvider {

    private val localFallback = LocalRulePlanner()

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    var personalityPrompt: String = "Stark Classic (Polite, Intelligent, Slightly Witty)"

    fun updateApiKey(key: String?) {
        customApiKey = key
    }

    override suspend fun planTask(userInput: String, userMemoryContext: String): ActionPlan {
        return planTaskWithHistory(userInput, emptyList(), userMemoryContext)
    }

    suspend fun planTaskWithHistory(
        userInput: String,
        history: List<ChatMessage>,
        userMemoryContext: String = ""
    ): ActionPlan {
        return planTaskWithHistoryAndAttachment(userInput, null, history, userMemoryContext).plan
    }

    suspend fun planTaskWithHistoryAndAttachment(
        userInput: String,
        attachment: MediaAttachment?,
        history: List<ChatMessage>,
        userMemoryContext: String = ""
    ): GeminiAnalysisResult = withContext(Dispatchers.IO) {
        val resolvedKey = customApiKey?.takeIf { it.isNotBlank() } ?: BuildConfig.GEMINI_API_KEY
        if (resolvedKey.isBlank() || resolvedKey == "MY_GEMINI_API_KEY") {
            // No valid API key configured; use our intelligent local engine
            val fallbackPlan = localFallback.planFromUserInput(userInput)
            return@withContext GeminiAnalysisResult(plan = fallbackPlan)
        }

        val systemPrompt = """
            You are JARVIS, a sophisticated, calm, intelligent, and multimodal AI assistant inspired by Tony Stark's AI in Iron Man.
            
            Personality traits:
            - Confident, articulate, polite, concise, and intellectually sharp.
            - Slightly witty when appropriate, but never cheesy, obnoxious, or overly robotic.
            - You address the user as "Sir" only occasionally (not in every sentence).
            - When answering general questions, be clear, direct, and conversational (like ChatGPT).
            - Remember the current conversation context and understand follow-up questions (e.g. if the user asked 'Who is Elon Musk?' and then asks 'How old is he?', you know 'he' refers to Elon Musk).
            - For coding or math, explain concisely and directly.
            - Do not include raw URLs, markdown asterisks, or formatting symbols inside 'speechResponse' because 'speechResponse' will be read aloud by Android Text-to-Speech.
            
            Multimodal Vision & Generation:
            - You have full multimodal vision intelligence. You can analyze photos, inspect screenshots, read documents/diagrams, recognize code in images, and understand user-provided pictures.
            - If the user asks to generate an image or draw something (e.g. "generate an image of...", "draw a futuristic car", "make a picture of..."):
              Set "mediaIntent": "IMAGE", and provide a detailed artistic "mediaPrompt".
            - If the user asks to generate a video or create a video from an image (e.g. "make a video...", "create a cinematic video from this picture"):
              Set "mediaIntent": "VIDEO", and provide a detailed cinematic "mediaPrompt".
            - Otherwise set "mediaIntent": "NONE".
            
            Device Operating Rules:
            ONLY generate device tool steps if the user EXPLICITLY asks to perform a phone action (such as opening an app, adjusting volume, setting an alarm, navigating the screen, or reading notifications).
            If the user is simply chatting, asking a question, seeking an explanation, analyzing an image, or asking to generate media, leave 'steps' EMPTY ([]).
            
            Available phone tools:
            - open_app(app: string)
            - tap_element(target: string)
            - scroll(direction: "up" | "down")
            - press_back()
            - go_home()
            - recent_apps()
            - take_screenshot()
            - search_web(query: string)
            - open_url(url: string)
            - draft_email(recipient: string, subject: string, body: string)
            - send_whatsapp(phone: string, message: string)
            - send_sms(recipient: string, body: string)
            - set_alarm(hour: string, minute: string, message: string)
            - set_timer(minutes: string, message: string)
            - create_calendar_event(title: string)
            - read_notifications()
            - toggle_wifi()
            - toggle_bluetooth()
            - open_settings(category: string)
            - adjust_volume(direction: "up" | "down")
            - find_file()
            
            Risk levels:
            - LOW: general conversation, searching, view actions, alarms, media generation.
            - MEDIUM: sending emails, sending messages, file modifications.
            - HIGH: financial, purchases, destructive actions.
            
            Respond strictly in valid JSON format:
            {
              "speechResponse": "Natural spoken response (without markdown formatting)",
              "mediaIntent": "NONE" | "IMAGE" | "VIDEO",
              "mediaPrompt": "Detailed prompt for image or video generation if requested, else empty",
              "riskLevel": "LOW" | "MEDIUM" | "HIGH",
              "requiresConfirmation": boolean,
              "confirmationTitle": string or null,
              "confirmationDetails": { key: value },
              "steps": [
                 {
                   "id": "1",
                   "title": "Short title",
                   "toolName": "name_of_tool",
                   "params": { "paramName": "value" }
                 }
              ]
            }
            User memory context: $userMemoryContext
        """.trimIndent()

        try {
            // Build multi-turn contents array from recent chat history (up to last 10 messages)
            val contentsArray = JSONArray()
            val recentHistory = history.takeLast(10)
            for (msg in recentHistory) {
                if (msg.text.isNotBlank()) {
                    val role = if (msg.sender == MessageSender.USER) "user" else "model"
                    val contentObj = JSONObject().apply {
                        put("role", role)
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                if (role == "model") {
                                    val simulatedJson = JSONObject().apply {
                                        put("speechResponse", msg.text)
                                        put("steps", JSONArray())
                                    }
                                    put("text", simulatedJson.toString())
                                } else {
                                    put("text", msg.text)
                                }
                            })
                        })
                    }
                    contentsArray.put(contentObj)
                }
            }

            // Current user turn with optional multimodal image / document attachment
            val currentParts = JSONArray()
            if (attachment?.base64Data != null && attachment.base64Data.isNotBlank()) {
                currentParts.put(JSONObject().apply {
                    put("inlineData", JSONObject().apply {
                        put("mimeType", attachment.mimeType)
                        put("data", attachment.base64Data)
                    })
                })
            }

            currentParts.put(JSONObject().apply {
                put("text", userInput.ifBlank { "Analyze this attached media." })
            })

            contentsArray.put(JSONObject().apply {
                put("role", "user")
                put("parts", currentParts)
            })

            val payload = JSONObject().apply {
                put("contents", contentsArray)
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", systemPrompt)
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.3)
                })
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$resolvedKey"
            val request = Request.Builder()
                .url(url)
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string()

            if (response.isSuccessful && !body.isNullOrBlank()) {
                val json = JSONObject(body)
                val text = json.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                val planJson = JSONObject(text)
                val rawSpeech = planJson.optString("speechResponse", "At your service, Sir.")
                val speech = SpeechSanitizer.cleanForSpeech(rawSpeech)
                val mediaIntent = planJson.optString("mediaIntent", "NONE").uppercase()
                val mediaPrompt = planJson.optString("mediaPrompt", "")

                val riskStr = planJson.optString("riskLevel", "LOW")
                val risk = when (riskStr.uppercase()) {
                    "HIGH" -> RiskLevel.HIGH
                    "MEDIUM" -> RiskLevel.MEDIUM
                    else -> RiskLevel.LOW
                }
                val reqConfirm = planJson.optBoolean("requiresConfirmation", risk != RiskLevel.LOW)
                val confirmTitle = if (planJson.has("confirmationTitle") && !planJson.isNull("confirmationTitle")) {
                    planJson.getString("confirmationTitle")
                } else null

                val detailsMap = mutableMapOf<String, String>()
                val detailsObj = planJson.optJSONObject("confirmationDetails")
                detailsObj?.keys()?.forEach { k ->
                    detailsMap[k] = detailsObj.optString(k, "")
                }

                val stepsList = mutableListOf<PlanStep>()
                val stepsArray = planJson.optJSONArray("steps")
                if (stepsArray != null) {
                    for (i in 0 until stepsArray.length()) {
                        val stepObj = stepsArray.getJSONObject(i)
                        val id = stepObj.optString("id", (i + 1).toString())
                        val title = stepObj.optString("title", "Action ${i + 1}")
                        val toolName = stepObj.optString("toolName", "unknown")
                        val paramsMap = mutableMapOf<String, String>()
                        val paramsObj = stepObj.optJSONObject("params")
                        paramsObj?.keys()?.forEach { pk ->
                            paramsMap[pk] = paramsObj.optString(pk, "")
                        }
                        stepsList.add(PlanStep(id, title, toolName, paramsMap))
                    }
                }

                val actionPlan = ActionPlan(
                    userIntent = userInput,
                    steps = stepsList,
                    riskLevel = risk,
                    requiresConfirmation = reqConfirm,
                    confirmationTitle = confirmTitle,
                    confirmationDetails = detailsMap,
                    speechResponse = speech
                )

                return@withContext GeminiAnalysisResult(
                    plan = actionPlan,
                    mediaIntent = mediaIntent,
                    mediaPrompt = mediaPrompt,
                    fullResponseText = rawSpeech
                )
            } else {
                val plan = localFallback.planFromUserInput(userInput)
                return@withContext GeminiAnalysisResult(plan = plan)
            }
        } catch (e: IOException) {
            val offlinePlan = ActionPlan(
                userIntent = userInput,
                steps = emptyList(),
                riskLevel = RiskLevel.LOW,
                speechResponse = "I'm currently offline, Sir. I can still perform supported local phone commands."
            )
            return@withContext GeminiAnalysisResult(plan = offlinePlan)
        } catch (e: Exception) {
            val fallbackPlan = localFallback.planFromUserInput(userInput)
            return@withContext GeminiAnalysisResult(plan = fallbackPlan)
        }
    }
}
