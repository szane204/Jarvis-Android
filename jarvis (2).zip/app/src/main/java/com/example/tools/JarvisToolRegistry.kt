package com.example.tools

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import com.example.accessibility.JarvisAccessibilityService
import com.example.model.PlanStep
import com.example.model.ToolResult
import com.example.notifications.JarvisNotificationListenerService
import java.net.URLEncoder

class JarvisToolRegistry(private val context: Context) {

    private val appControlManager = AppControlManager(context)

    fun execute(step: PlanStep): ToolResult {
        return when (step.toolName.lowercase()) {
            "open_app" -> {
                val appName = step.params["app"] ?: step.params["name"] ?: ""
                if (appName.isBlank()) {
                    ToolResult(false, "open_app", "No app specified")
                } else {
                    appControlManager.launchAppByName(appName)
                }
            }

            "tap_element" -> {
                val target = step.params["target"] ?: step.params["text"] ?: ""
                val service = JarvisAccessibilityService.instance
                if (service == null) {
                    ToolResult(
                        success = false,
                        action = "tap_element",
                        result = "Accessibility Service is offline.",
                        error = "AccessibilityDisabled",
                        limitationNote = "Please enable JARVIS Accessibility Service in Android Settings to allow UI interaction."
                    )
                } else {
                    val clicked = service.findAndClick(target)
                    if (clicked) {
                        ToolResult(true, "tap_element", "Tapped UI element containing '$target'")
                    } else {
                        ToolResult(
                            success = false,
                            action = "tap_element",
                            result = "Could not locate a clickable element matching '$target' on the active screen.",
                            error = "ElementNotFound"
                        )
                    }
                }
            }

            "scroll" -> {
                val direction = step.params["direction"] ?: "down"
                val forward = direction.lowercase() == "down" || direction.lowercase() == "forward"
                val service = JarvisAccessibilityService.instance
                if (service == null) {
                    ToolResult(
                        success = false,
                        action = "scroll",
                        result = "Accessibility Service is offline.",
                        error = "AccessibilityDisabled"
                    )
                } else {
                    val scrolled = service.scroll(forward)
                    if (scrolled) {
                        ToolResult(true, "scroll", "Scrolled $direction successfully")
                    } else {
                        ToolResult(true, "scroll", "Attempted scroll, no further scrollable content detected")
                    }
                }
            }

            "press_back", "go_back" -> {
                val service = JarvisAccessibilityService.instance
                if (service != null && service.performBack()) {
                    ToolResult(true, "press_back", "Navigated back")
                } else {
                    ToolResult(
                        false,
                        "press_back",
                        "Accessibility Service not active for global navigation",
                        limitationNote = "Enable JARVIS Accessibility Service in Settings"
                    )
                }
            }

            "go_home" -> {
                val service = JarvisAccessibilityService.instance
                if (service != null && service.performHome()) {
                    ToolResult(true, "go_home", "Navigated to Home screen")
                } else {
                    val intent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_HOME)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ToolResult(true, "go_home", "Navigated to Home screen via Launcher Intent")
                }
            }

            "recent_apps" -> {
                val service = JarvisAccessibilityService.instance
                if (service != null && service.performRecents()) {
                    ToolResult(true, "recent_apps", "Opened Recent Apps overview")
                } else {
                    ToolResult(false, "recent_apps", "Accessibility Service required to open Recent Apps")
                }
            }

            "take_screenshot" -> {
                val service = JarvisAccessibilityService.instance
                if (service != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val taken = service.performTakeScreenshot()
                    if (taken) {
                        ToolResult(true, "take_screenshot", "Screenshot captured by JARVIS")
                    } else {
                        ToolResult(false, "take_screenshot", "Failed to initiate screenshot capture")
                    }
                } else {
                    ToolResult(
                        false,
                        "take_screenshot",
                        "Screenshot capability requires Android 11+ and JARVIS Accessibility Service enabled.",
                        limitationNote = "Enable Accessibility Service in Android Settings."
                    )
                }
            }

            "search_web" -> {
                val query = step.params["query"] ?: ""
                try {
                    val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                        putExtra(SearchManager.QUERY, query)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ToolResult(true, "search_web", "Opened web search for '$query'")
                } catch (e: Exception) {
                    val webIntent = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://www.google.com/search?q=${URLEncoder.encode(query, "UTF-8")}")
                    ).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(webIntent)
                    ToolResult(true, "search_web", "Opened search results in browser for '$query'")
                }
            }

            "open_url" -> {
                val url = step.params["url"] ?: "https://google.com"
                val fullUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) "https://$url" else url
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fullUrl)).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ToolResult(true, "open_url", "Opened $fullUrl")
            }

            "draft_email", "send_email" -> {
                val recipient = step.params["recipient"] ?: step.params["to"] ?: ""
                val subject = step.params["subject"] ?: "Message via JARVIS"
                val body = step.params["body"] ?: step.params["message"] ?: ""

                val uri = Uri.parse("mailto:$recipient")
                val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
                    putExtra(Intent.EXTRA_SUBJECT, subject)
                    putExtra(Intent.EXTRA_TEXT, body)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                try {
                    context.startActivity(intent)
                    ToolResult(
                        true,
                        step.toolName,
                        "Prepared email to ${if (recipient.isNotBlank()) recipient else "recipient"} with message: '$body'"
                    )
                } catch (e: Exception) {
                    ToolResult(
                        false,
                        step.toolName,
                        "No email client installed or available to handle mailto intent",
                        error = e.message
                    )
                }
            }

            "send_whatsapp" -> {
                val phone = step.params["phone"] ?: ""
                val message = step.params["message"] ?: ""
                val encodedMsg = URLEncoder.encode(message, "UTF-8")
                val url = if (phone.isNotBlank()) {
                    val cleanPhone = phone.replace(Regex("[^0-9]"), "")
                    "https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMsg"
                } else {
                    "https://api.whatsapp.com/send?text=$encodedMsg"
                }
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    setPackage("com.whatsapp")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                try {
                    context.startActivity(intent)
                    ToolResult(true, "send_whatsapp", "Opened WhatsApp with message '$message'")
                } catch (e: Exception) {
                    // Try generic browser link
                    try {
                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(browserIntent)
                        ToolResult(true, "send_whatsapp", "Opened WhatsApp web link")
                    } catch (ex: Exception) {
                        ToolResult(
                            false,
                            "send_whatsapp",
                            "WhatsApp is not installed or accessible on this device",
                            error = "WhatsAppNotInstalled"
                        )
                    }
                }
            }

            "send_sms" -> {
                val recipient = step.params["recipient"] ?: step.params["phone"] ?: ""
                val body = step.params["body"] ?: step.params["message"] ?: ""
                val uri = Uri.parse("smsto:$recipient")
                val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
                    putExtra("sms_body", body)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                try {
                    context.startActivity(intent)
                    ToolResult(true, "send_sms", "Prepared SMS to $recipient: '$body'")
                } catch (e: Exception) {
                    ToolResult(false, "send_sms", "No SMS messaging application found", error = e.message)
                }
            }

            "set_alarm" -> {
                val hour = step.params["hour"]?.toIntOrNull() ?: 7
                val minute = step.params["minute"]?.toIntOrNull() ?: 0
                val message = step.params["message"] ?: "JARVIS Alarm"
                val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, hour)
                    putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    putExtra(AlarmClock.EXTRA_MESSAGE, message)
                    putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                try {
                    context.startActivity(intent)
                    val formattedTime = String.format("%02d:%02d", hour, minute)
                    ToolResult(true, "set_alarm", "Alarm set for $formattedTime ($message)")
                } catch (e: Exception) {
                    ToolResult(false, "set_alarm", "Unable to set alarm via system clock", error = e.message)
                }
            }

            "set_timer" -> {
                val minutes = step.params["minutes"]?.toIntOrNull() ?: 10
                val seconds = minutes * 60
                val message = step.params["message"] ?: "JARVIS Timer"
                val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                    putExtra(AlarmClock.EXTRA_MESSAGE, message)
                    putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                try {
                    context.startActivity(intent)
                    ToolResult(true, "set_timer", "Timer set for $minutes minutes ($message)")
                } catch (e: Exception) {
                    ToolResult(false, "set_timer", "Unable to set timer via system clock", error = e.message)
                }
            }

            "create_calendar_event" -> {
                val title = step.params["title"] ?: "Meeting"
                val intent = Intent(Intent.ACTION_INSERT).apply {
                    data = CalendarContract.Events.CONTENT_URI
                    putExtra(CalendarContract.Events.TITLE, title)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                try {
                    context.startActivity(intent)
                    ToolResult(true, "create_calendar_event", "Opened Calendar to create event '$title'")
                } catch (e: Exception) {
                    ToolResult(false, "create_calendar_event", "No calendar application available", error = e.message)
                }
            }

            "read_notifications" -> {
                if (!JarvisNotificationListenerService.isNotificationAccessGranted(context)) {
                    ToolResult(
                        false,
                        "read_notifications",
                        "Notification Access has not been granted to JARVIS.",
                        limitationNote = "Please allow notification access in Android Settings."
                    )
                } else {
                    val summary = JarvisNotificationListenerService.getNotificationSummary()
                    ToolResult(true, "read_notifications", summary)
                }
            }

            "toggle_wifi" -> {
                val state = step.params["state"] ?: "settings"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val panelIntent = Intent(Settings.Panel.ACTION_WIFI).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    try {
                        context.startActivity(panelIntent)
                        ToolResult(
                            true,
                            "toggle_wifi",
                            "Opened Android Wi-Fi panel. Modern Android security requires toggling Wi-Fi directly in the panel."
                        )
                    } catch (e: Exception) {
                        val settingsIntent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(settingsIntent)
                        ToolResult(true, "toggle_wifi", "Opened Wi-Fi Settings")
                    }
                } else {
                    val settingsIntent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(settingsIntent)
                    ToolResult(true, "toggle_wifi", "Opened Wi-Fi Settings")
                }
            }

            "toggle_bluetooth" -> {
                val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ToolResult(true, "toggle_bluetooth", "Opened Bluetooth Settings")
            }

            "open_settings" -> {
                val target = step.params["category"] ?: ""
                val intent = when (target.lowercase()) {
                    "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
                    "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                    "sound", "volume" -> Intent(Settings.ACTION_SOUND_SETTINGS)
                    "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
                    "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    "notifications" -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    else -> Intent(Settings.ACTION_SETTINGS)
                }.apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ToolResult(true, "open_settings", "Opened Android System Settings")
            }

            "adjust_volume" -> {
                val direction = step.params["direction"] ?: "up"
                val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val adj = if (direction.lowercase() == "up" || direction.lowercase() == "increase") {
                    AudioManager.ADJUST_RAISE
                } else {
                    AudioManager.ADJUST_LOWER
                }
                audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    adj,
                    AudioManager.FLAG_SHOW_UI
                )
                ToolResult(true, "adjust_volume", "Adjusted media volume $direction")
            }

            "find_file", "show_files" -> {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                try {
                    context.startActivity(intent)
                    ToolResult(true, "find_file", "Opened device file manager via Storage Access Framework")
                } catch (e: Exception) {
                    ToolResult(false, "find_file", "Unable to open device file selector", error = e.message)
                }
            }

            else -> {
                ToolResult(
                    false,
                    step.toolName,
                    "Unknown tool '${step.toolName}' requested.",
                    error = "ToolNotFound"
                )
            }
        }
    }
}
