package com.example.tools

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import com.example.model.ToolResult

data class InstalledApp(
    val label: String,
    val packageName: String
)

class AppControlManager(private val context: Context) {

    fun getInstalledApps(): List<InstalledApp> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(intent, 0)
        return resolveInfos.mapNotNull { info ->
            val pkg = info.activityInfo.packageName
            val label = info.loadLabel(pm).toString()
            if (pkg.isNotBlank() && label.isNotBlank()) {
                InstalledApp(label = label, packageName = pkg)
            } else null
        }.distinctBy { it.packageName }
    }

    fun launchAppByName(name: String): ToolResult {
        val query = name.trim().lowercase()

        // Direct system settings mapping
        if (query == "settings" || query == "system settings") {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            return ToolResult(
                success = true,
                action = "open_app",
                result = "Opened Android System Settings"
            )
        }

        // Camera shortcut
        if (query == "camera") {
            val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                return ToolResult(
                    success = true,
                    action = "open_app",
                    result = "Opened Camera"
                )
            }
        }

        val installed = getInstalledApps()
        // Exact match
        var target = installed.find { it.label.equals(query, ignoreCase = true) }

        // Common nicknames
        if (target == null) {
            val mappedQuery = when (query) {
                "insta" -> "instagram"
                "wa", "whats app" -> "whatsapp"
                "yt" -> "youtube"
                "google" -> "chrome"
                "mail" -> "gmail"
                "photos", "gallery" -> "photos"
                else -> query
            }
            target = installed.find { it.label.contains(mappedQuery, ignoreCase = true) }
                ?: installed.find { it.packageName.contains(mappedQuery, ignoreCase = true) }
        }

        if (target != null) {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(target.packageName)
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(launchIntent)
                return ToolResult(
                    success = true,
                    action = "open_app",
                    result = "Successfully launched ${target.label}"
                )
            }
        }

        // If not found installed, offer Play Store link or web alternative
        return ToolResult(
            success = false,
            action = "open_app",
            result = "Application '$name' is not currently installed on this device.",
            error = "AppNotFound",
            limitationNote = "You can install $name from the Google Play Store."
        )
    }
}
