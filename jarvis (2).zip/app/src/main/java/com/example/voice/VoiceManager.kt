package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.util.SpeechSanitizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import kotlin.random.Random

enum class JarvisVoiceStatus {
    IDLE,
    STANDBY,          // Monitoring for "Hey JARVIS" wake phrase
    WAKING,           // Just acknowledged ("Yes, Alex?")
    LISTENING,        // Actively recording user speech command
    THINKING,         // Conversational AI / Task planning
    SPEAKING,         // Vocalizing response via TTS
    GENERATING_IMAGE, // Creating AI Image
    GENERATING_VIDEO, // Creating AI Video
    GENERATING,       // Long-running generation
    ERROR             // Error state
}

class VoiceManager(
    private val context: Context,
    private val onVoiceResult: (String) -> Unit
) {

    var onStopRequested: (() -> Unit)? = null
    var userName: String = "Alex"

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null

    private val _status = MutableStateFlow(JarvisVoiceStatus.STANDBY)
    val status: StateFlow<JarvisVoiceStatus> = _status.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _rmsAmplitude = MutableStateFlow(0f)
    val rmsAmplitude: StateFlow<Float> = _rmsAmplitude.asStateFlow()

    private val _partialText = MutableStateFlow("")
    val partialText: StateFlow<String> = _partialText.asStateFlow()

    private val _speechError = MutableStateFlow<String?>(null)
    val speechError: StateFlow<String?> = _speechError.asStateFlow()

    // Settings
    val isWakeWordEnabled = MutableStateFlow(true)
    val isAlwaysListening = MutableStateFlow(true)
    val voiceResponsesEnabled = MutableStateFlow(true)

    var pitch: Float = 0.95f
    var speechRate: Float = 1.0f

    private var followUpRunnable: Runnable? = null
    private var wakeWordCycleRunnable: Runnable? = null

    fun setStatus(newStatus: JarvisVoiceStatus) {
        _status.value = newStatus
    }

    private fun getWakeAcknowledgement(): String {
        val acks = listOf(
            "Yes, $userName?",
            "At your service, $userName.",
            "How can I help, $userName?",
            "Yes?"
        )
        return acks[Random.nextInt(acks.size)]
    }

    init {
        initTts()
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale.US
                textToSpeech?.setPitch(pitch)
                textToSpeech?.setSpeechRate(speechRate)
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                        _status.value = JarvisVoiceStatus.SPEAKING
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        mainHandler.post {
                            if (isAlwaysListening.value) {
                                // Transition immediately to active listening for follow-up questions
                                startActiveListening()
                                scheduleFollowUpTimeout()
                            } else if (isWakeWordEnabled.value) {
                                startWakeWordMonitoring()
                            } else {
                                _status.value = JarvisVoiceStatus.STANDBY
                            }
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                        mainHandler.post {
                            if (isWakeWordEnabled.value) {
                                startWakeWordMonitoring()
                            } else {
                                _status.value = JarvisVoiceStatus.STANDBY
                            }
                        }
                    }
                })
            }
        }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!voiceResponsesEnabled.value || text.isBlank()) {
            if (isAlwaysListening.value) {
                startActiveListening()
            } else if (isWakeWordEnabled.value) {
                startWakeWordMonitoring()
            }
            return
        }

        cancelFollowUpTimeout()
        stopListening()
        textToSpeech?.setPitch(pitch)
        textToSpeech?.setSpeechRate(speechRate)
        _isSpeaking.value = true
        _status.value = JarvisVoiceStatus.SPEAKING

        val cleanSpokenText = SpeechSanitizer.cleanForSpeech(text)
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "JARVIS_${System.currentTimeMillis()}")
        }
        textToSpeech?.speak(cleanSpokenText, TextToSpeech.QUEUE_FLUSH, params, "JARVIS_RESPONSE")
    }

    fun stopSpeaking() {
        if (_isSpeaking.value) {
            textToSpeech?.stop()
            _isSpeaking.value = false
            if (_status.value == JarvisVoiceStatus.SPEAKING) {
                _status.value = JarvisVoiceStatus.STANDBY
            }
        }
    }

    /**
     * Actively listens for a full command or question.
     */
    fun startActiveListening() {
        mainHandler.post {
            cancelFollowUpTimeout()
            stopSpeaking()
            _speechError.value = null
            _partialText.value = ""
            _status.value = JarvisVoiceStatus.LISTENING

            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                _speechError.value = "Speech recognition unavailable"
                return@post
            }

            try {
                ensureRecognizer()
                speechRecognizer?.setRecognitionListener(createActiveRecognitionListener())

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
                }

                speechRecognizer?.startListening(intent)
                _isListening.value = true
            } catch (e: Exception) {
                _isListening.value = false
                _speechError.value = e.message
                resetRecognizer()
            }
        }
    }

    /**
     * Efficiently monitors for the "Hey JARVIS" wake phrase.
     */
    fun startWakeWordMonitoring() {
        mainHandler.post {
            if (!isWakeWordEnabled.value) {
                _status.value = JarvisVoiceStatus.STANDBY
                return@post
            }

            if (_isSpeaking.value || _status.value == JarvisVoiceStatus.LISTENING || _status.value == JarvisVoiceStatus.THINKING) {
                return@post
            }

            _status.value = JarvisVoiceStatus.STANDBY
            _partialText.value = ""

            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                return@post
            }

            try {
                ensureRecognizer()
                speechRecognizer?.setRecognitionListener(createWakeWordListener())

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                }

                speechRecognizer?.startListening(intent)
                _isListening.value = true
            } catch (e: Exception) {
                _isListening.value = false
                resetRecognizer()
                // Retry wake cycle after brief pause
                scheduleWakeWordRetry(1500)
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            cancelFollowUpTimeout()
            if (_isListening.value) {
                try {
                    speechRecognizer?.stopListening()
                } catch (e: Exception) {
                    // Safe catch
                }
                _isListening.value = false
                _rmsAmplitude.value = 0f
            }
        }
    }

    private fun ensureRecognizer() {
        if (speechRecognizer == null) {
            speechRecognizer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
            ) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
            } else {
                SpeechRecognizer.createSpeechRecognizer(context)
            }
        }
    }

    private fun resetRecognizer() {
        try {
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            // Ignore
        }
        speechRecognizer = null
    }

    private fun createActiveRecognitionListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _isListening.value = true
                _speechError.value = null
            }

            override fun onBeginningOfSpeech() {
                _isListening.value = true
                cancelFollowUpTimeout()
            }

            override fun onRmsChanged(rmsdB: Float) {
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                _rmsAmplitude.value = normalized

                // Interruption check: If user starts speaking loudly while JARVIS is speaking
                if (_isSpeaking.value && normalized > 0.45f) {
                    stopSpeaking()
                }
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _isListening.value = false
                _rmsAmplitude.value = 0f
            }

            override fun onError(error: Int) {
                _isListening.value = false
                _rmsAmplitude.value = 0f

                if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) {
                    resetRecognizer()
                }

                // If no speech recognized during active listening
                if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    _speechError.value = "Sorry, I didn't catch that."
                }

                // Smoothly return to wake word monitoring if enabled
                if (isWakeWordEnabled.value) {
                    scheduleWakeWordRetry(1000)
                } else {
                    _status.value = JarvisVoiceStatus.STANDBY
                }
            }

            override fun onResults(results: Bundle?) {
                _isListening.value = false
                _rmsAmplitude.value = 0f
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.trim()
                if (!text.isNullOrBlank()) {
                    _partialText.value = text
                    if (isStopCommand(text)) {
                        stopSpeaking()
                        onStopRequested?.invoke()
                        _status.value = JarvisVoiceStatus.STANDBY
                        return
                    }
                    _status.value = JarvisVoiceStatus.THINKING
                    onVoiceResult(text)
                } else {
                    if (isWakeWordEnabled.value) {
                        startWakeWordMonitoring()
                    } else {
                        _status.value = JarvisVoiceStatus.STANDBY
                    }
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.trim()
                if (!text.isNullOrBlank()) {
                    _partialText.value = text
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    private fun createWakeWordListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _isListening.value = true
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                _rmsAmplitude.value = normalized * 0.4f // subtle standby glow
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _isListening.value = false
            }

            override fun onError(error: Int) {
                _isListening.value = false
                if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) {
                    resetRecognizer()
                }
                if (isWakeWordEnabled.value && _status.value == JarvisVoiceStatus.STANDBY) {
                    scheduleWakeWordRetry(1000)
                }
            }

            override fun onResults(results: Bundle?) {
                _isListening.value = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                handleWakePhrases(matches)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                handleWakePhrases(matches)
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    private fun handleWakePhrases(matches: List<String>) {
        if (_status.value != JarvisVoiceStatus.STANDBY) return

        for (phrase in matches) {
            val lower = phrase.lowercase(Locale.ROOT).trim()

            // Check if user said "Hey JARVIS", "JARVIS", "Okay JARVIS", "Hi JARVIS"
            val wakePatterns = listOf("hey jarvis", "jarvis", "okay jarvis", "ok jarvis", "hi jarvis")
            val matchedPattern = wakePatterns.firstOrNull { lower.startsWith(it) || lower.contains(it) }

            if (matchedPattern != null) {
                // Check if user spoke a command in the same sentence: "Hey JARVIS what's the weather today"
                val remainder = lower.substringAfter(matchedPattern).trim(' ', ',', '.')
                if (remainder.length > 2) {
                    // Direct command execution without delay
                    _status.value = JarvisVoiceStatus.THINKING
                    _partialText.value = remainder
                    onVoiceResult(remainder)
                    return
                }

                // Isolated "Hey JARVIS" wake up
                _status.value = JarvisVoiceStatus.WAKING
                stopListening()

                val ack = getWakeAcknowledgement()
                _partialText.value = ack

                // Speak short acknowledgement, then immediately start active listening
                speak(ack)
                return
            }
        }

        // No wake phrase detected; continue monitoring if enabled
        if (isWakeWordEnabled.value && _status.value == JarvisVoiceStatus.STANDBY) {
            scheduleWakeWordRetry(500)
        }
    }

    private fun scheduleWakeWordRetry(delayMs: Long) {
        wakeWordCycleRunnable?.let { mainHandler.removeCallbacks(it) }
        wakeWordCycleRunnable = Runnable {
            if (isWakeWordEnabled.value && _status.value == JarvisVoiceStatus.STANDBY && !_isSpeaking.value) {
                startWakeWordMonitoring()
            }
        }
        mainHandler.postDelayed(wakeWordCycleRunnable!!, delayMs)
    }

    private fun scheduleFollowUpTimeout() {
        cancelFollowUpTimeout()
        followUpRunnable = Runnable {
            if (_status.value == JarvisVoiceStatus.LISTENING) {
                stopListening()
                if (isWakeWordEnabled.value) {
                    startWakeWordMonitoring()
                } else {
                    _status.value = JarvisVoiceStatus.STANDBY
                }
            }
        }
        mainHandler.postDelayed(followUpRunnable!!, 7000L) // 7 seconds listening window for follow-ups
    }

    private fun cancelFollowUpTimeout() {
        followUpRunnable?.let {
            mainHandler.removeCallbacks(it)
            followUpRunnable = null
        }
    }

    private fun isStopCommand(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT).trim()
        val stops = listOf("stop", "cancel", "jarvis stop", "quiet", "shut up", "pause", "halt")
        return stops.any { lower == it || lower.startsWith("jarvis stop") }
    }

    fun destroy() {
        mainHandler.post {
            cancelFollowUpTimeout()
            wakeWordCycleRunnable?.let { mainHandler.removeCallbacks(it) }
            stopListening()
            resetRecognizer()
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
        }
    }
}
