package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "jarvis_memory")
data class MemoryItem(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val key: String,
    val value: String,
    val category: String = "general",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "jarvis_routines")
data class RoutineItem(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val description: String,
    val triggerPhrase: String,
    val stepsRaw: String, // newline-separated commands
    val isEnabled: Boolean = true
)

@Entity(tableName = "jarvis_command_logs")
data class CommandLogItem(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val query: String,
    val response: String,
    val success: Boolean,
    val toolsExecuted: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
