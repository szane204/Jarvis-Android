package com.example.data

import com.example.data.dao.JarvisDao
import com.example.data.model.CommandLogItem
import com.example.data.model.MemoryItem
import com.example.data.model.RoutineItem
import kotlinx.coroutines.flow.Flow

class JarvisRepository(private val dao: JarvisDao) {
    val allMemory: Flow<List<MemoryItem>> = dao.getAllMemory()
    val allRoutines: Flow<List<RoutineItem>> = dao.getAllRoutines()
    val allLogs: Flow<List<CommandLogItem>> = dao.getAllLogs()

    suspend fun getMemoryByKey(key: String): MemoryItem? = dao.getMemoryByKey(key)
    suspend fun saveMemory(item: MemoryItem) = dao.insertMemory(item)
    suspend fun deleteMemory(id: Int) = dao.deleteMemory(id)

    suspend fun saveRoutine(routine: RoutineItem) = dao.insertRoutine(routine)
    suspend fun updateRoutine(routine: RoutineItem) = dao.updateRoutine(routine)
    suspend fun deleteRoutine(id: Int) = dao.deleteRoutine(id)

    suspend fun logCommand(query: String, response: String, success: Boolean, tools: String) {
        dao.insertLog(
            CommandLogItem(
                query = query,
                response = response,
                success = success,
                toolsExecuted = tools
            )
        )
    }

    suspend fun clearLogs() = dao.clearLogs()
}
