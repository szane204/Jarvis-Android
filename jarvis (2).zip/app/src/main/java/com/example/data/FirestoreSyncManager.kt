package com.example.data

import android.content.Context
import android.util.Log
import com.example.data.model.CommandLogItem
import com.example.data.model.MemoryItem
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class FirestoreSyncManager(private val context: Context) {

    private val firestore: FirebaseFirestore? = try {
        FirebaseApp.initializeApp(context)
        FirebaseFirestore.getInstance()
    } catch (e: Exception) {
        Log.w("FirestoreSyncManager", "Firestore initialization deferred: ${e.message}")
        null
    }

    /**
     * Sync user preferences and preferred name to cloud Firestore.
     */
    suspend fun syncUserProfile(uid: String, preferredName: String, settingsMap: Map<String, Any>) = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext
        try {
            val data = hashMapOf(
                "preferredName" to preferredName,
                "lastActive" to System.currentTimeMillis(),
                "settings" to settingsMap
            )
            db.collection("users").document(uid).set(data, SetOptions.merge()).await()
        } catch (e: Exception) {
            Log.e("FirestoreSyncManager", "Failed to sync user profile", e)
        }
    }

    /**
     * Sync a memory fact to cloud Firestore.
     */
    suspend fun syncMemory(uid: String, memory: MemoryItem) = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext
        try {
            val doc = hashMapOf(
                "key" to memory.key,
                "value" to memory.value,
                "category" to memory.category,
                "updatedAt" to memory.updatedAt
            )
            db.collection("users").document(uid).collection("memories")
                .document(memory.key)
                .set(doc, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.e("FirestoreSyncManager", "Failed to sync memory to Firestore", e)
        }
    }

    /**
     * Sync command history to cloud Firestore.
     */
    suspend fun syncCommandLog(uid: String, log: CommandLogItem) = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext
        try {
            val doc = hashMapOf(
                "query" to log.query,
                "response" to log.response,
                "success" to log.success,
                "tools" to log.toolsExecuted,
                "timestamp" to log.timestamp
            )
            db.collection("users").document(uid).collection("command_logs")
                .add(doc)
                .await()
        } catch (e: Exception) {
            Log.e("FirestoreSyncManager", "Failed to sync command log", e)
        }
    }
}
