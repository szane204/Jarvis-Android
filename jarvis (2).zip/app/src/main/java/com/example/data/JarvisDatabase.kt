package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.JarvisDao
import com.example.data.model.CommandLogItem
import com.example.data.model.MemoryItem
import com.example.data.model.RoutineItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [MemoryItem::class, RoutineItem::class, CommandLogItem::class],
    version = 1,
    exportSchema = false
)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun jarvisDao(): JarvisDao

    companion object {
        @Volatile
        private var INSTANCE: JarvisDatabase? = null

        fun getInstance(context: Context): JarvisDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    JarvisDatabase::class.java,
                    "jarvis_os_database.db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Seed initial memory and routines
                            CoroutineScope(Dispatchers.IO).launch {
                                val dao = getInstance(context).jarvisDao()
                                dao.insertMemory(
                                    MemoryItem(
                                        key = "preferred_name",
                                        value = "Sir",
                                        category = "identity"
                                    )
                                )
                                dao.insertMemory(
                                    MemoryItem(
                                        key = "preferred_email",
                                        value = "Gmail",
                                        category = "apps"
                                    )
                                )
                                dao.insertRoutine(
                                    RoutineItem(
                                        name = "Good Morning Routine",
                                        description = "Summarizes notifications, opens calendar, checks system state",
                                        triggerPhrase = "Good morning",
                                        stepsRaw = "read notifications\nwhat's on my calendar\nturn wifi on"
                                    )
                                )
                                dao.insertRoutine(
                                    RoutineItem(
                                        name = "Work Focus Mode",
                                        description = "Sets timer for 45 minutes, opens calendar",
                                        triggerPhrase = "Start work mode",
                                        stepsRaw = "set a timer for 45 minutes\nwhat's on my calendar"
                                    )
                                )
                            }
                        }
                    })
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
