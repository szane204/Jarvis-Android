package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CommandLogItem
import com.example.data.model.MemoryItem
import com.example.data.model.RoutineItem
import kotlinx.coroutines.flow.Flow

@Dao
interface JarvisDao {
    // Memory
    @Query("SELECT * FROM jarvis_memory ORDER BY updatedAt DESC")
    fun getAllMemory(): Flow<List<MemoryItem>>

    @Query("SELECT * FROM jarvis_memory WHERE `key` = :key LIMIT 1")
    suspend fun getMemoryByKey(key: String): MemoryItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(item: MemoryItem): Long

    @Query("DELETE FROM jarvis_memory WHERE id = :id")
    suspend fun deleteMemory(id: Int)

    // Routines
    @Query("SELECT * FROM jarvis_routines ORDER BY name ASC")
    fun getAllRoutines(): Flow<List<RoutineItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutine(item: RoutineItem): Long

    @Update
    suspend fun updateRoutine(item: RoutineItem)

    @Query("DELETE FROM jarvis_routines WHERE id = :id")
    suspend fun deleteRoutine(id: Int)

    // Command Logs
    @Query("SELECT * FROM jarvis_command_logs ORDER BY timestamp DESC LIMIT 100")
    fun getAllLogs(): Flow<List<CommandLogItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: CommandLogItem): Long

    @Query("DELETE FROM jarvis_command_logs")
    suspend fun clearLogs()
}
