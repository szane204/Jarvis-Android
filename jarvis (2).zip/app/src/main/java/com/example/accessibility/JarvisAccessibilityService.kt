package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceConnected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Track current window/state changes if needed
    }

    override fun onInterrupt() {
        // Service interrupted
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
            _isServiceConnected.value = false
        }
    }

    // --- Screen Control Actions ---

    fun performBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun performRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun performNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun performQuickSettings(): Boolean = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)

    fun performTakeScreenshot(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        } else {
            false
        }
    }

    fun findAndClick(targetText: String, ignoreCase: Boolean = true): Boolean {
        val root = rootInActiveWindow ?: return false
        val cleanTarget = targetText.trim()
        val matchingNodes = mutableListOf<AccessibilityNodeInfo>()
        findNodesByTextRecursively(root, cleanTarget, ignoreCase, matchingNodes)

        for (node in matchingNodes) {
            // Find clickable target: either this node or an ancestor
            var current: AccessibilityNodeInfo? = node
            while (current != null) {
                if (current.isClickable) {
                    val clicked = current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    if (clicked) return true
                }
                current = current.parent
            }
        }
        return false
    }

    fun scroll(forward: Boolean = true): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollableNodes = mutableListOf<AccessibilityNodeInfo>()
        findScrollableNodes(root, scrollableNodes)

        val action = if (forward) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }

        for (node in scrollableNodes) {
            if (node.performAction(action)) {
                return true
            }
        }
        return false
    }

    fun findAndSetText(text: String, hintOrLabel: String? = null): Boolean {
        val root = rootInActiveWindow ?: return false
        val editableNodes = mutableListOf<AccessibilityNodeInfo>()
        findEditableNodes(root, editableNodes)

        val target = if (!hintOrLabel.isNullOrBlank()) {
            editableNodes.find {
                it.text?.contains(hintOrLabel, ignoreCase = true) == true ||
                it.hintText?.contains(hintOrLabel, ignoreCase = true) == true ||
                it.contentDescription?.contains(hintOrLabel, ignoreCase = true) == true
            } ?: editableNodes.firstOrNull()
        } else {
            editableNodes.firstOrNull()
        } ?: return false

        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun getVisibleTexts(max: Int = 30): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val texts = mutableListOf<String>()
        collectAllTexts(root, texts, max)
        return texts.distinct()
    }

    fun dispatchSwipe(startX: Float, startY: Float, endX: Float, endY: Float, durationMs: Long = 300): Boolean {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    private fun findNodesByTextRecursively(
        node: AccessibilityNodeInfo?,
        targetText: String,
        ignoreCase: Boolean,
        result: MutableList<AccessibilityNodeInfo>
    ) {
        if (node == null) return
        val nodeText = node.text?.toString() ?: ""
        val nodeDesc = node.contentDescription?.toString() ?: ""

        val matches = if (ignoreCase) {
            nodeText.contains(targetText, ignoreCase = true) ||
            nodeDesc.contains(targetText, ignoreCase = true)
        } else {
            nodeText.contains(targetText) || nodeDesc.contains(targetText)
        }

        if (matches) {
            result.add(node)
        }

        for (i in 0 until node.childCount) {
            findNodesByTextRecursively(node.getChild(i), targetText, ignoreCase, result)
        }
    }

    private fun findScrollableNodes(node: AccessibilityNodeInfo?, result: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        if (node.isScrollable) {
            result.add(node)
        }
        for (i in 0 until node.childCount) {
            findScrollableNodes(node.getChild(i), result)
        }
    }

    private fun findEditableNodes(node: AccessibilityNodeInfo?, result: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        if (node.isEditable) {
            result.add(node)
        }
        for (i in 0 until node.childCount) {
            findEditableNodes(node.getChild(i), result)
        }
    }

    private fun collectAllTexts(node: AccessibilityNodeInfo?, result: MutableList<String>, max: Int) {
        if (node == null || result.size >= max) return
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if (!text.isNullOrBlank()) result.add(text)
        if (!desc.isNullOrBlank() && desc != text) result.add(desc)

        for (i in 0 until node.childCount) {
            collectAllTexts(node.getChild(i), result, max)
        }
    }

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null

        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()

        fun isServiceEnabled(context: Context): Boolean {
            if (instance != null) return true
            val expectedServiceName = "${context.packageName}/${JarvisAccessibilityService::class.java.canonicalName}"
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabledServices.contains(expectedServiceName) ||
                   enabledServices.contains(JarvisAccessibilityService::class.java.simpleName)
        }

        fun openAccessibilitySettings(context: Context) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }
    }
}
