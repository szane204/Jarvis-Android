package com.example.model

enum class JarvisState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    GENERATING_IMAGE,
    GENERATING_VIDEO,
    GENERATING,
    EXECUTING,
    ERROR
}

enum class RiskLevel {
    LOW,
    MEDIUM,
    HIGH
}

enum class StepStatus {
    PENDING,
    RUNNING,
    SUCCESS,
    FAILED,
    CANCELLED
}

enum class MediaType {
    IMAGE,
    DOCUMENT,
    VIDEO,
    AUDIO
}

data class MediaAttachment(
    val uri: String? = null,
    val type: MediaType = MediaType.IMAGE,
    val base64Data: String? = null,
    val mimeType: String = "image/jpeg",
    val title: String? = null,
    val previewThumbnail: String? = null
)

data class GeneratedMedia(
    val type: MediaType,
    val urlOrPath: String,
    val prompt: String,
    val resolution: String? = "1024x1024",
    val durationSeconds: Int? = null,
    val progressPercent: Int = 100,
    val localUri: String? = null
)

data class VideoStoryboard(
    val title: String,
    val masterPrompt: String,
    val subjectAction: String,
    val cameraMovement: String,
    val lightingAtmosphere: String,
    val styleAesthetics: String,
    val durationSeconds: Int = 5,
    val aspectRatio: String = "16:9",
    val audioDesign: String? = null,
    val scenes: List<String> = emptyList(),
    val isApiConnected: Boolean = false,
    val generatedVideoUrl: String? = null
)

data class PlanStep(
    val id: String,
    val title: String,
    val toolName: String,
    val params: Map<String, String> = emptyMap(),
    var status: StepStatus = StepStatus.PENDING,
    var resultDetail: String? = null
)

data class ActionPlan(
    val id: String = System.currentTimeMillis().toString(),
    val userIntent: String,
    val steps: List<PlanStep>,
    val riskLevel: RiskLevel = RiskLevel.LOW,
    val requiresConfirmation: Boolean = false,
    val confirmationTitle: String? = null,
    val confirmationDetails: Map<String, String> = emptyMap(),
    val speechResponse: String
)

data class ToolResult(
    val success: Boolean,
    val action: String,
    val result: String,
    val error: String? = null,
    val limitationNote: String? = null
)

enum class MessageSender {
    USER,
    JARVIS
}

data class ChatMessage(
    val id: String = System.currentTimeMillis().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val plan: ActionPlan? = null,
    val attachment: MediaAttachment? = null,
    val generatedMedia: GeneratedMedia? = null,
    val videoStoryboard: VideoStoryboard? = null
)
