package com.example.notifications

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class JarvisNotification(
    val id: String,
    val packageName: String,
    val appName: String,
    val title: String,
    val text: String,
    val postTime: Long
)

class JarvisNotificationListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        _isListenerConnected.value = true
        refreshNotifications()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance == this) {
            instance = null
            _isListenerConnected.value = false
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        refreshNotifications()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        refreshNotifications()
    }

    fun refreshNotifications() {
        try {
            val active = activeNotifications ?: return
            val list = active.mapNotNull { sbn ->
                val extras = sbn.notification?.extras ?: return@mapNotNull null
                val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
                val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
                if (title.isBlank() && text.isBlank()) return@mapNotNull null

                val pkg = sbn.packageName ?: "system"
                val appLabel = try {
                    val appInfo = packageManager.getApplicationInfo(pkg, 0)
                    packageManager.getApplicationLabel(appInfo).toString()
                } catch (e: Exception) {
                    pkg.substringAfterLast('.')
                }

                JarvisNotification(
                    id = "${sbn.id}_${sbn.postTime}",
                    packageName = pkg,
                    appName = appLabel,
                    title = title,
                    text = text,
                    postTime = sbn.postTime
                )
            }.sortedByDescending { it.postTime }

            _recentNotifications.value = list
        } catch (e: Exception) {
            // Handle notification query exceptions
        }
    }

    companion object {
        @Volatile
        var instance: JarvisNotificationListenerService? = null

        private val _isListenerConnected = MutableStateFlow(false)
        val isListenerConnected: StateFlow<Boolean> = _isListenerConnected.asStateFlow()

        private val _recentNotifications = MutableStateFlow<List<JarvisNotification>>(emptyList())
        val recentNotifications: StateFlow<List<JarvisNotification>> = _recentNotifications.asStateFlow()

        fun isNotificationAccessGranted(context: Context): Boolean {
            val componentName = ComponentName(context, JarvisNotificationListenerService::class.java)
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
            return flat != null && flat.contains(componentName.flattenToString())
        }

        fun openNotificationAccessSettings(context: Context) {
            val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }

        fun getNotificationSummary(): String {
            val current = _recentNotifications.value
            if (current.isEmpty()) {
                return "You have no active notifications at the moment, Sir."
            }
            val grouped = current.groupBy { it.appName }
            val breakdown = grouped.entries.joinToString(", ") { "${it.value.size} from ${it.key}" }
            val topNotifications = current.take(3).joinToString("; ") { "${it.appName}: ${it.title} - ${it.text}" }

            return "You have ${current.size} active notifications ($breakdown). Most recent: $topNotifications."
        }
    }
}
