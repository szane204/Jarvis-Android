package com.example

import android.app.Application
import com.example.ai.JarvisBrain
import com.example.data.JarvisDatabase
import com.example.data.JarvisRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class JarvisApp : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    lateinit var database: JarvisDatabase
        private set

    lateinit var repository: JarvisRepository
        private set

    lateinit var brain: JarvisBrain
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = JarvisDatabase.getInstance(this)
        repository = JarvisRepository(database.jarvisDao())
        brain = JarvisBrain(this, repository, applicationScope)
    }

    companion object {
        lateinit var instance: JarvisApp
            private set
    }
}
