package com.example.util

object SpeechSanitizer {
    /**
     * Cleans an AI response text for natural Text-To-Speech delivery:
     * - Strips markdown headers, bold, italics, strikethrough, blockquotes
     * - Replaces code blocks with a brief spoken indicator
     * - Cleans raw URLs
     * - Normalizes punctuation and spacing so speech sounds completely natural.
     */
    fun cleanForSpeech(input: String): String {
        if (input.isBlank()) return ""

        var text = input

        // 1. Remove markdown code blocks (e.g. ```kotlin ... ```)
        text = text.replace(Regex("```[\\w]*\\n[\\s\\S]*?\\n```"), " I have prepared the code snippet on your screen. ")
        text = text.replace(Regex("```[\\s\\S]*?```"), " Code omitted for speech. ")

        // 2. Remove inline code `code`
        text = text.replace(Regex("`([^`]+)`"), "$1")

        // 3. Remove raw URLs (e.g. https://example.com)
        text = text.replace(Regex("https?://\\S+"), "a web link")

        // 4. Remove Markdown headers (# Header, ## Subheader)
        text = text.replace(Regex("(?m)^#{1,6}\\s*"), "")

        // 5. Remove bold and italics formatting (**text**, *text*, __text__, _text_)
        text = text.replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
        text = text.replace(Regex("\\*([^*]+)\\*"), "$1")
        text = text.replace(Regex("__([^_]+)__"), "$1")
        text = text.replace(Regex("(?<=\\s|^)_([^_]+)_(?=\\s|$)"), "$1")

        // 6. Remove Markdown bullet points (- Item, * Item, 1. Item)
        text = text.replace(Regex("(?m)^\\s*[-*+]\\s+"), "")
        text = text.replace(Regex("(?m)^\\s*\\d+\\.\\s+"), "")

        // 7. Remove blockquotes (> text)
        text = text.replace(Regex("(?m)^>\\s*"), "")

        // 8. Remove bracketed formatting / decorative characters [text] -> text
        text = text.replace(Regex("\\[([^\\]]+)\\]\\([^)]+\\)"), "$1") // [Title](url) -> Title
        text = text.replace(Regex("[~`^|{}\\[\\]]"), " ")

        // 9. Normalize multiple punctuation or symbols (e.g. "...", "---", "***")
        text = text.replace(Regex("-{2,}"), " - ")
        text = text.replace(Regex("\\*{2,}"), "")

        // 10. Normalize whitespace and clean ends
        text = text.replace(Regex("\\s+"), " ").trim()

        return text
    }
}
