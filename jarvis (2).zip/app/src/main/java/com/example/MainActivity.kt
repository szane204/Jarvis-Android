package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.accessibility.JarvisAccessibilityService
import com.example.notifications.JarvisNotificationListenerService
import com.example.ui.MainViewModel
import com.example.ui.screens.ActionHubScreen
import com.example.ui.screens.DiagnosticsScreen
import com.example.ui.screens.MainConsoleScreen
import com.example.ui.screens.RoutinesMemoryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavyCardBorder
import com.example.ui.theme.DeepVoidBlack
import com.example.ui.theme.HologramAmber
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextCyberDim
import com.example.ui.theme.TextCyberWhite

enum class JarvisScreen(val title: String, val icon: ImageVector) {
    CONSOLE("Console", Icons.Default.SmartToy),
    ACTIONS("Action Hub", Icons.Default.FlashOn),
    ROUTINES("Routines", Icons.Default.PlayCircle),
    SYSTEM("Telemetry", Icons.Default.Sensors),
    SETTINGS("Settings", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableHighRefreshRate()
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val preferences = remember { getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE) }
                var showOnboardingDialog by remember {
                    mutableStateOf(!preferences.getBoolean("onboarding_name_completed", false))
                }
                var onboardingNameInput by remember { mutableStateOf("") }

                LaunchedEffect(showOnboardingDialog) {
                    if (showOnboardingDialog) {
                        viewModel.voiceManager.speak("Before we begin, what should I call you?")
                    }
                }

                var currentScreen by remember { mutableStateOf(JarvisScreen.CONSOLE) }
                var showPermissionDialog by remember { mutableStateOf(false) }

                // Audio permission check
                var hasAudioPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                    )
                }

                val permissionLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    hasAudioPermission = isGranted
                    if (isGranted) {
                        viewModel.voiceManager.startWakeWordMonitoring()
                    } else {
                        showPermissionDialog = true
                    }
                }

                // Initial launch: Request permission or start wake word monitoring
                LaunchedEffect(Unit) {
                    if (hasAudioPermission) {
                        viewModel.voiceManager.startWakeWordMonitoring()
                    } else {
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }

                // Handle back button: if not on Console, return to Console!
                BackHandler(enabled = currentScreen != JarvisScreen.CONSOLE) {
                    currentScreen = JarvisScreen.CONSOLE
                }

                // State collection
                val jarvisState by viewModel.state.collectAsStateWithLifecycle()
                val voiceStatus by viewModel.jarvisStatus.collectAsStateWithLifecycle()
                val messages by viewModel.messages.collectAsStateWithLifecycle()
                val currentPlan by viewModel.currentPlan.collectAsStateWithLifecycle()
                val pendingConfirmationPlan by viewModel.pendingConfirmationPlan.collectAsStateWithLifecycle()
                val isAccessibilityConnected by viewModel.isAccessibilityConnected.collectAsStateWithLifecycle()
                val isNotificationListenerConnected by viewModel.isNotificationListenerConnected.collectAsStateWithLifecycle()
                val isListening by viewModel.isListening.collectAsStateWithLifecycle()
                val isSpeaking by viewModel.isSpeaking.collectAsStateWithLifecycle()
                val rmsAmplitude by viewModel.rmsAmplitude.collectAsStateWithLifecycle()
                val partialSpeechText by viewModel.partialSpeechText.collectAsStateWithLifecycle()
                val isWakeWordEnabled by viewModel.isWakeWordEnabled.collectAsStateWithLifecycle()
                val isAlwaysListening by viewModel.isAlwaysListening.collectAsStateWithLifecycle()
                val voiceResponsesEnabled by viewModel.voiceResponsesEnabled.collectAsStateWithLifecycle()
                val aiPersonality by viewModel.aiPersonality.collectAsStateWithLifecycle()
                val userName by viewModel.userName.collectAsStateWithLifecycle()
                val pendingAttachment by viewModel.pendingAttachment.collectAsStateWithLifecycle()
                val speechError by viewModel.speechError.collectAsStateWithLifecycle()
                val routines by viewModel.routines.collectAsStateWithLifecycle()
                val memories by viewModel.memories.collectAsStateWithLifecycle()
                val voicePitch by viewModel.voicePitch.collectAsStateWithLifecycle()
                val voiceRate by viewModel.voiceRate.collectAsStateWithLifecycle()
                val useCloudAi by viewModel.useCloudAi.collectAsStateWithLifecycle()
                val customApiKey by viewModel.customApiKey.collectAsStateWithLifecycle()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = DeepVoidBlack,
                    bottomBar = {
                        NavigationBar(
                            containerColor = DarkNavyCard,
                            tonalElevation = 8.dp,
                            modifier = Modifier
                                .border(1.dp, DarkNavyCardBorder)
                                .testTag("main_bottom_nav")
                        ) {
                            JarvisScreen.values().forEach { screen ->
                                val selected = currentScreen == screen
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentScreen = screen },
                                    icon = {
                                        Icon(
                                            imageVector = screen.icon,
                                            contentDescription = screen.title,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = screen.title,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = DeepVoidBlack,
                                        selectedTextColor = NeonCyan,
                                        indicatorColor = NeonCyan,
                                        unselectedIconColor = TextCyberDim,
                                        unselectedTextColor = TextCyberDim
                                    ),
                                    modifier = Modifier.testTag("nav_${screen.name.lowercase()}")
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentScreen) {
                            JarvisScreen.CONSOLE -> {
                                MainConsoleScreen(
                                    state = jarvisState,
                                    voiceStatus = voiceStatus,
                                    rmsAmplitude = rmsAmplitude,
                                    messages = messages,
                                    currentPlan = currentPlan,
                                    pendingConfirmationPlan = pendingConfirmationPlan,
                                    pendingAttachment = pendingAttachment,
                                    isAccessibilityConnected = isAccessibilityConnected || JarvisAccessibilityService.isServiceEnabled(this@MainActivity),
                                    isNotificationListenerConnected = isNotificationListenerConnected || JarvisNotificationListenerService.isNotificationAccessGranted(this@MainActivity),
                                    isWakeWordEnabled = isWakeWordEnabled,
                                    isAlwaysListening = isAlwaysListening,
                                    isListening = isListening,
                                    isSpeaking = isSpeaking,
                                    partialSpeechText = partialSpeechText,
                                    speechError = speechError,
                                    onStartVoice = {
                                        if (hasAudioPermission) {
                                            viewModel.startVoice()
                                        } else {
                                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        }
                                    },
                                    onStopVoice = { viewModel.stopVoice() },
                                    onStopSpeaking = { viewModel.stopSpeaking() },
                                    onStopRequested = { viewModel.stopCurrentOperation() },
                                    onSetAttachment = { viewModel.setPendingAttachment(it) },
                                    onSubmitText = { text -> viewModel.submitUserInput(text) },
                                    onConfirmPlan = { viewModel.confirmPendingPlan() },
                                    onCancelPlan = { viewModel.cancelPendingPlan() },
                                    onNavigateToDiagnostics = { currentScreen = JarvisScreen.SYSTEM },
                                    onNavigateToSettings = { currentScreen = JarvisScreen.SETTINGS }
                                )
                            }

                            JarvisScreen.ACTIONS -> {
                                ActionHubScreen(
                                    toolRegistry = viewModel.brain.toolRegistry
                                )
                            }

                            JarvisScreen.ROUTINES -> {
                                RoutinesMemoryScreen(
                                    routines = routines,
                                    memories = memories,
                                    onTriggerRoutine = { routine ->
                                        currentScreen = JarvisScreen.CONSOLE
                                        viewModel.triggerRoutine(routine)
                                    },
                                    onSaveRoutine = { name, desc, trigger, steps ->
                                        viewModel.saveRoutine(name, desc, trigger, steps)
                                    },
                                    onDeleteRoutine = { id -> viewModel.deleteRoutine(id) },
                                    onSaveMemory = { key, value, cat -> viewModel.saveMemory(key, value, cat) },
                                    onDeleteMemory = { id -> viewModel.deleteMemory(id) }
                                )
                            }

                            JarvisScreen.SYSTEM -> {
                                DiagnosticsScreen(
                                    isAccessibilityEnabled = isAccessibilityConnected || JarvisAccessibilityService.isServiceEnabled(this@MainActivity),
                                    isNotificationListenerEnabled = isNotificationListenerConnected || JarvisNotificationListenerService.isNotificationAccessGranted(this@MainActivity),
                                    hasRecordAudioPermission = hasAudioPermission,
                                    onOpenAccessibilitySettings = {
                                        JarvisAccessibilityService.openAccessibilitySettings(this@MainActivity)
                                    },
                                    onOpenNotificationSettings = {
                                        JarvisNotificationListenerService.openNotificationAccessSettings(this@MainActivity)
                                    },
                                    onRequestRecordAudioPermission = {
                                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                )
                            }

                            JarvisScreen.SETTINGS -> {
                                SettingsScreen(
                                    userName = userName,
                                    onUpdateUserName = { viewModel.updateUserName(it) },
                                    isWakeWordEnabled = isWakeWordEnabled,
                                    onToggleWakeWord = { viewModel.setWakeWordEnabled(it) },
                                    isAlwaysListening = isAlwaysListening,
                                    onToggleAlwaysListening = { viewModel.setAlwaysListening(it) },
                                    voiceResponsesEnabled = voiceResponsesEnabled,
                                    onToggleVoiceResponses = { viewModel.setVoiceResponsesEnabled(it) },
                                    aiPersonality = aiPersonality,
                                    onSelectPersonality = { viewModel.setAiPersonality(it) },
                                    useCloudAi = useCloudAi,
                                    onToggleCloudAi = { viewModel.toggleCloudAi(it) },
                                    currentApiKey = customApiKey,
                                    onUpdateApiKey = { viewModel.updateApiKey(it) },
                                    voicePitch = voicePitch,
                                    onUpdatePitch = { viewModel.updatePitch(it) },
                                    voiceRate = voiceRate,
                                    onUpdateRate = { viewModel.updateRate(it) },
                                    onTestVoice = { viewModel.testVoice() },
                                    onClearConversation = { viewModel.clearConversation() },
                                    onOpenMicSettings = { openAppSettings(this@MainActivity) },
                                    onOpenAccessibilitySettings = { JarvisAccessibilityService.openAccessibilitySettings(this@MainActivity) },
                                    hasMicPermission = hasAudioPermission,
                                    isAccessibilityEnabled = isAccessibilityConnected || JarvisAccessibilityService.isServiceEnabled(this@MainActivity)
                                )
                            }
                        }

                        // First-Launch Personalization Dialog: "Before we begin, what should I call you?"
                        if (showOnboardingDialog) {
                            AlertDialog(
                                onDismissRequest = {
                                    showOnboardingDialog = false
                                    preferences.edit().putBoolean("onboarding_name_completed", true).apply()
                                },
                                title = {
                                    Text(
                                        text = "INITIALIZATION PROTOCOL",
                                        color = NeonCyan,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                },
                                text = {
                                    Column {
                                        Text(
                                            text = "Before we begin, what should I call you?",
                                            color = TextCyberWhite,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Spacer(modifier = Modifier.height(10.dp))
                                        OutlinedTextField(
                                            value = onboardingNameInput,
                                            onValueChange = { onboardingNameInput = it },
                                            placeholder = { Text("Enter your name (e.g. Alex)", fontSize = 12.sp) },
                                            singleLine = true,
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = NeonCyan,
                                                unfocusedBorderColor = DarkNavyCardBorder,
                                                focusedTextColor = TextCyberWhite,
                                                unfocusedTextColor = TextCyberWhite
                                            ),
                                            modifier = Modifier.fillMaxWidth().testTag("onboarding_name_field")
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "JARVIS will address you by this name during voice conversations.",
                                            color = TextCyberDim,
                                            fontSize = 11.sp
                                        )
                                    }
                                },
                                confirmButton = {
                                    Button(
                                        onClick = {
                                            val finalName = onboardingNameInput.trim().ifBlank { "Alex" }
                                            viewModel.updateUserName(finalName)
                                            viewModel.voiceManager.speak("Understood, $finalName.")
                                            preferences.edit().putBoolean("onboarding_name_completed", true).apply()
                                            showOnboardingDialog = false
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = NeonCyan,
                                            contentColor = DeepVoidBlack
                                        )
                                    ) {
                                        Text("Confirm Name", fontWeight = FontWeight.Bold)
                                    }
                                },
                                dismissButton = {
                                    OutlinedButton(
                                        onClick = {
                                            viewModel.updateUserName("Alex")
                                            preferences.edit().putBoolean("onboarding_name_completed", true).apply()
                                            showOnboardingDialog = false
                                        }
                                    ) {
                                        Text("Use Default (Alex)")
                                    }
                                },
                                containerColor = DarkNavyCard
                            )
                        }

                        // Microphone Permission Rationale Dialog if denied
                        if (showPermissionDialog) {
                            AlertDialog(
                                onDismissRequest = { showPermissionDialog = false },
                                title = {
                                    Text(
                                        text = "Microphone Access Required",
                                        color = TextCyberWhite,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                text = {
                                    Column {
                                        Text(
                                            text = "JARVIS requires microphone permission to listen for the \"Hey JARVIS\" wake phrase and process your spoken voice commands.",
                                            color = TextCyberDim,
                                            fontSize = 13.sp
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "Audio is processed securely for speech recognition without permanent recording.",
                                            color = TextCyberDim,
                                            fontSize = 11.sp
                                        )
                                    }
                                },
                                confirmButton = {
                                    Button(
                                        onClick = {
                                            showPermissionDialog = false
                                            openAppSettings(this@MainActivity)
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = NeonCyan,
                                            contentColor = DeepVoidBlack
                                        )
                                    ) {
                                        Text("Open App Settings")
                                    }
                                },
                                dismissButton = {
                                    OutlinedButton(onClick = { showPermissionDialog = false }) {
                                        Text("Cancel")
                                    }
                                },
                                containerColor = DarkNavyCard
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            if (viewModel.isWakeWordEnabled.value) {
                viewModel.voiceManager.startWakeWordMonitoring()
            }
        }
    }

    private fun openAppSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
        }
        context.startActivity(intent)
    }

    private fun enableHighRefreshRate() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setPreferMinimalPostProcessing(true)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val currentDisplay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    this.display
                } else {
                    @Suppress("DEPRECATION")
                    windowManager.defaultDisplay
                }
                val modes = currentDisplay?.supportedModes
                val highRateMode = modes?.filter { it.refreshRate >= 119.0f }?.maxByOrNull { it.refreshRate }
                val layoutParams = window.attributes
                if (highRateMode != null) {
                    layoutParams.preferredDisplayModeId = highRateMode.modeId
                } else {
                    layoutParams.preferredRefreshRate = 120.0f
                }
                window.attributes = layoutParams
            } catch (e: Exception) {
                // Graceful fallback on devices that lock refresh rate modes
            }
        }
    }
}
