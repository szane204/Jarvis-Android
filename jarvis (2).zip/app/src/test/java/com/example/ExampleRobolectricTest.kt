package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ai.AIBrain
import com.example.ai.DeviceActionCategory
import com.example.ai.GeminiMultimodalClient
import com.example.ai.LocalRulePlanner
import com.example.ai.MediaGenerator
import com.example.ai.RequestContext
import com.example.ai.RoutedIntent
import com.example.model.RiskLevel
import com.example.util.SpeechSanitizer
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `verify app name resource matches JARVIS`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("JARVIS", appName)
    }

    @Test
    fun `test speech sanitizer strips markdown and URLs for natural voice delivery`() {
        val rawMarkdown = "**Tokyo** is the capital of Japan. Visit https://example.com for more info. ```val x = 1```"
        val cleaned = SpeechSanitizer.cleanForSpeech(rawMarkdown)
        assertFalse(cleaned.contains("**"))
        assertFalse(cleaned.contains("https://"))
        assertFalse(cleaned.contains("```"))
        assertTrue(cleaned.contains("Tokyo is the capital of Japan"))
    }

    @Test
    fun `test video storyboard generation creates detailed cinematic prompt`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val generator = MediaGenerator(context)
        val storyboard = generator.createVideoStoryboard("Futuristic flying car racing through neon Tokyo at night")
        assertNotNull(storyboard.masterPrompt)
        assertTrue(storyboard.masterPrompt.contains("Tokyo", ignoreCase = true))
        assertTrue(storyboard.scenes.isNotEmpty())
        assertEquals(10, storyboard.durationSeconds)
        assertEquals("16:9", storyboard.aspectRatio)
    }

    @Test
    fun `test AIBrain routes web search query`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val aiBrain = AIBrain(context)
        val decision = aiBrain.routeIntent("Hey JARVIS, search for latest quantum computing news", RequestContext())
        assertTrue(decision is RoutedIntent.WebSearch)
        val search = decision as RoutedIntent.WebSearch
        assertTrue(search.query.contains("quantum computing", ignoreCase = true))
    }

    @Test
    fun `test AIBrain routes image generation intent`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val aiBrain = AIBrain(context)
        val decision = aiBrain.routeIntent("Create an image of an Iron Man workshop with neon holograms", RequestContext())
        assertTrue(decision is RoutedIntent.ImageGeneration)
        val imageGen = decision as RoutedIntent.ImageGeneration
        assertTrue(imageGen.rawPrompt.contains("Iron Man workshop", ignoreCase = true))
        assertTrue(imageGen.optimizedPrompt.contains("photorealistic", ignoreCase = true))
    }

    @Test
    fun `test AIBrain routes device action for app launch and alarm`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val aiBrain = AIBrain(context)

        val appDecision = aiBrain.routeIntent("Hey JARVIS, open YouTube", RequestContext())
        assertTrue(appDecision is RoutedIntent.DeviceAction)
        val appAction = appDecision as RoutedIntent.DeviceAction
        assertEquals(DeviceActionCategory.LAUNCH_APP, appAction.category)
        assertEquals("YouTube", appAction.target)

        val alarmDecision = aiBrain.routeIntent("JARVIS, set an alarm for 6:30 AM", RequestContext())
        assertTrue(alarmDecision is RoutedIntent.DeviceAction)
        val alarmAction = alarmDecision as RoutedIntent.DeviceAction
        assertEquals(DeviceActionCategory.SET_ALARM, alarmAction.category)
        assertEquals("6", alarmAction.parameters["hour"])
        assertEquals("30", alarmAction.parameters["minute"])
    }

    @Test
    fun `test AIBrain routes user name and memory declaration`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val aiBrain = AIBrain(context)

        val nameDecision = aiBrain.routeIntent("My name is Alex", RequestContext())
        assertTrue(nameDecision is RoutedIntent.MemoryOperation)
        val mem = nameDecision as RoutedIntent.MemoryOperation
        assertEquals("user_name", mem.key)
        assertEquals("Alex", mem.value)
    }

    @Test
    fun `test AIBrain routes music generation request to Lyria`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val aiBrain = AIBrain(context)
        val decision = aiBrain.routeIntent("JARVIS, generate music: an epic sci-fi soundtrack", RequestContext())
        assertTrue(decision is RoutedIntent.MusicGeneration)
        val music = decision as RoutedIntent.MusicGeneration
        assertTrue(music.rawPrompt.contains("sci-fi", ignoreCase = true))
        assertTrue(music.optimizedPrompt.contains("electronic orchestral", ignoreCase = true))
    }

    @Test
    fun `test GeminiMultimodalClient automated master prompt generation`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val client = GeminiMultimodalClient(context)
        val prompt = client.autoGeneratePrompt("flying car over Tokyo", "VIDEO")
        assertNotNull(prompt.fullMasterPrompt)
        assertTrue(prompt.subject.contains("flying car over Tokyo"))
        assertTrue(prompt.camera.contains("Cinematic", ignoreCase = true))
        assertTrue(prompt.lighting.contains("rim lighting", ignoreCase = true))
    }

    @Test
    fun `test local planner app launch intent`() {
        val planner = LocalRulePlanner()
        val plan = planner.planFromUserInput("Hey JARVIS, open Instagram")
        assertEquals(1, plan.steps.size)
        assertEquals("open_app", plan.steps[0].toolName)
        assertEquals("Instagram", plan.steps[0].params["app"])
    }

    @Test
    fun `test local planner search intent`() {
        val planner = LocalRulePlanner()
        val plan = planner.planFromUserInput("JARVIS, search YouTube for GTA 6")
        assertEquals(2, plan.steps.size)
        assertEquals("open_app", plan.steps[0].toolName)
        assertEquals("search_web", plan.steps[1].toolName)
        assertEquals("GTA 6", plan.steps[1].params["query"])
    }

    @Test
    fun `test local planner alarm command`() {
        val planner = LocalRulePlanner()
        val plan = planner.planFromUserInput("JARVIS, set an alarm for 7 AM")
        assertEquals(1, plan.steps.size)
        assertEquals("set_alarm", plan.steps[0].toolName)
        assertEquals("7", plan.steps[0].params["hour"])
        assertEquals("0", plan.steps[0].params["minute"])
    }

    @Test
    fun `test local planner email safety confirmation`() {
        val planner = LocalRulePlanner()
        val plan = planner.planFromUserInput("JARVIS, send an email to Sarah saying I'll arrive at 5")
        assertEquals(RiskLevel.MEDIUM, plan.riskLevel)
        assertTrue(plan.requiresConfirmation)
        assertEquals("Sarah", plan.steps[0].params["recipient"])
    }

    @Test
    fun `test local planner accessibility tap and scroll`() {
        val planner = LocalRulePlanner()
        val tapPlan = planner.planFromUserInput("JARVIS, tap the button that says Continue")
        assertEquals("tap_element", tapPlan.steps[0].toolName)
        assertEquals("Continue", tapPlan.steps[0].params["target"])

        val scrollPlan = planner.planFromUserInput("JARVIS, scroll down")
        assertEquals("scroll", scrollPlan.steps[0].toolName)
        assertEquals("down", scrollPlan.steps[0].params["direction"])
    }
}
